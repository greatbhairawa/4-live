export type ScreenId =
  | 'splash'
  | 'auth'
  | 'home'
  | 'start_live'
  | 'platform_select'
  | 'stream_settings'
  | 'live_preview'
  | 'live_streaming'
  | 'creator_studio'
  | 'scenes'
  | 'overlays'
  | 'chat'
  | 'game_library'
  | 'stream_history'
  | 'profile'
  | 'settings';

export type Resolution = '480p' | '720p' | '1080p';
export type FpsRate = 30 | 60;
export type BitrateMode = 'auto' | 'manual';
export type OrientationMode = 'portrait' | 'landscape';

export interface StreamSettings {
  resolution: Resolution;
  fps: FpsRate;
  bitrateMode: BitrateMode;
  manualBitrateKbps: number; // e.g. 4500
  orientation: OrientationMode;
  microphoneEnabled: boolean;
  gameAudioEnabled: boolean;
  cameraEnabled: boolean;
  audioBitrateKbps: number; // 128 | 160 | 192
  keyframeIntervalSeconds: number; // 1 | 2
  hardwareEncoder: boolean;
}

export type PlatformId = 'youtube' | 'facebook' | 'kick' | 'twitch' | 'custom_rtmp';

export interface PlatformConfig {
  id: PlatformId;
  name: string;
  icon: string;
  color: string;
  connected: boolean;
  username?: string;
  streamUrl?: string;
  streamKey?: string;
  latencyMode: 'ultra_low' | 'low' | 'normal';
}

export interface GameItem {
  id: string;
  name: string;
  category: string;
  bannerUrl: string;
  iconUrl: string;
  activePlayers?: string;
  packageId: string;
}

export interface SceneItem {
  id: string;
  name: string;
  tagline: string;
  layout: 'game_full' | 'cam_dominant' | 'intermission' | 'be_right_back' | 'starting_soon';
  showChat: boolean;
  showCamera: boolean;
  showAlerts: boolean;
  backgroundPattern: string;
}

export interface OverlayConfig {
  id: string;
  name: string;
  themeColor: string;
  borderStyle: 'cyber' | 'stealth' | 'crimson' | 'champion' | 'none';
  showGoalBar: boolean;
  goalTitle: string;
  goalCurrent: number;
  goalTarget: number;
  showSocials: boolean;
  socialHandle: string;
  camPosition: 'top_left' | 'top_right' | 'bottom_left' | 'bottom_right';
  camShape: 'circle' | 'rounded_rect' | 'hexagon';
}

export interface ChatMessage {
  id: string;
  sender: string;
  avatar: string;
  message: string;
  timestamp: string;
  isMod?: boolean;
  isSub?: boolean;
  superChatAmount?: number;
  color?: string;
}

export interface PastStream {
  id: string;
  title: string;
  game: string;
  gameBanner: string;
  date: string;
  duration: string;
  totalViews: number;
  peakCcu: number;
  platforms: PlatformId[];
  performanceScore: number;
  thumbnailUrl: string;
}

export interface StreamSessionState {
  title: string;
  description: string;
  selectedGame: GameItem;
  privacy: 'public' | 'unlisted' | 'private';
  tags: string[];
  selectedPlatforms: PlatformId[];
  settings: StreamSettings;
  activeSceneId: string;
  overlay: OverlayConfig;
  // Live broadcast stats
  isLive: boolean;
  liveDurationSeconds: number;
  currentBitrate: number;
  fpsActual: number;
  viewersCount: number;
  droppedFrames: number;
  isPaused: boolean;
  isMicMuted: boolean;
  isCamHidden: boolean;
}
