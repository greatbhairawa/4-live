import React, { useState } from 'react';
import { ScreenId, StreamSessionState, OverlayConfig, PlatformConfig, GameItem, PastStream, PlatformId } from './types/stream';
import {
  INITIAL_GAMES,
  INITIAL_PLATFORMS,
  INITIAL_SCENES,
  INITIAL_OVERLAY,
  INITIAL_PAST_STREAMS,
  DEFAULT_SETTINGS,
} from './data/mockData';
import { AndroidFrame } from './components/android-frame/AndroidFrame';
import { BottomNav } from './components/common/BottomNav';

// 16 Screens
import { SplashScreen } from './components/screens/SplashScreen';
import { AuthScreen } from './components/screens/AuthScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { StartLiveScreen } from './components/screens/StartLiveScreen';
import { PlatformSelectionScreen } from './components/screens/PlatformSelectionScreen';
import { StreamSettingsScreen } from './components/screens/StreamSettingsScreen';
import { LivePreviewScreen } from './components/screens/LivePreviewScreen';
import { LiveStreamingScreen } from './components/screens/LiveStreamingScreen';
import { CreatorStudioScreen } from './components/screens/CreatorStudioScreen';
import { ScenesScreen } from './components/screens/ScenesScreen';
import { OverlaysScreen } from './components/screens/OverlaysScreen';
import { ChatScreen } from './components/screens/ChatScreen';
import { GameLibraryScreen } from './components/screens/GameLibraryScreen';
import { StreamHistoryScreen } from './components/screens/StreamHistoryScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';

// Modals
import { CodeInspectorModal } from './components/modals/CodeInspectorModal';
import { Code2, Radio, Layers, RotateCw, ExternalLink, Sparkles } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('home');
  const [streamerName, setStreamerName] = useState('NeonStriker_4L');
  const [games, setGames] = useState<GameItem[]>(INITIAL_GAMES);
  const [platforms, setPlatforms] = useState<PlatformConfig[]>(INITIAL_PLATFORMS);
  const [scenes, setScenes] = useState(INITIAL_SCENES);
  const [overlay, setOverlay] = useState<OverlayConfig>(INITIAL_OVERLAY);
  const [history, setHistory] = useState<PastStream[]>(INITIAL_PAST_STREAMS);
  const [showCodeModal, setShowCodeModal] = useState(false);

  // Active Session State
  const [session, setSession] = useState<StreamSessionState>({
    title: 'Solo vs Squads - Ranked Push to Conqueror 🔥',
    description: 'High kill gameplay with viewers. Drop your gamer tags in live chat!',
    selectedGame: INITIAL_GAMES[0],
    privacy: 'public',
    tags: ['PUBGMobile', 'Esports', '4Live', 'Ranked'],
    selectedPlatforms: ['youtube', 'twitch'],
    settings: DEFAULT_SETTINGS,
    activeSceneId: 'scene-game',
    overlay: INITIAL_OVERLAY,
    isLive: false,
    liveDurationSeconds: 42,
    currentBitrate: 5400,
    fpsActual: 60,
    viewersCount: 428,
    droppedFrames: 0,
    isPaused: false,
    isMicMuted: false,
    isCamHidden: false,
  });

  // Flow handlers
  const handleGoLiveStart = () => {
    setCurrentScreen('start_live');
  };

  const handleStartLiveConfirm = () => {
    setSession((prev) => ({
      ...prev,
      isLive: true,
      liveDurationSeconds: 1,
    }));
    setCurrentScreen('live_streaming');
  };

  const handleEndStream = () => {
    setSession((prev) => ({
      ...prev,
      isLive: false,
    }));
    setCurrentScreen('home');
  };

  const handleTogglePlatform = (id: PlatformId) => {
    setSession((prev) => {
      const exists = prev.selectedPlatforms.includes(id);
      const updated = exists
        ? prev.selectedPlatforms.filter((p) => p !== id)
        : [...prev.selectedPlatforms, id];
      return { ...prev, selectedPlatforms: updated };
    });
  };

  const handleUpdateCustomRtmp = (url: string, key: string) => {
    setPlatforms((prev) =>
      prev.map((p) =>
        p.id === 'custom_rtmp'
          ? { ...p, streamUrl: url, streamKey: key, connected: true }
          : p
      )
    );
    if (!session.selectedPlatforms.includes('custom_rtmp')) {
      handleTogglePlatform('custom_rtmp');
    }
  };

  const shouldShowBottomNav =
    currentScreen === 'home' ||
    currentScreen === 'game_library' ||
    currentScreen === 'scenes' ||
    currentScreen === 'creator_studio' ||
    currentScreen === 'profile';

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Application Bar */}
      <header className="px-4 py-2.5 bg-neutral-900/90 border-b border-neutral-800/80 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 shrink-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-600 via-rose-500 to-amber-500 flex items-center justify-center shadow-[0_0_15px_rgba(244,63,94,0.4)]">
            <Radio className="w-4 h-4 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm tracking-tight text-white">4 LIVE</span>
              <span className="text-[10px] text-rose-400 font-semibold bg-rose-500/10 border border-rose-500/20 px-2 py-0.2 rounded-full">
                Native Android • Kotlin • Compose
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 hidden sm:block">
              Play • Stream • Connect • Create — Mobile Screen Broadcasting App
            </p>
          </div>
        </div>

        {/* Quick Screen Switcher Dropdown (Allows testing all 16 screens directly) */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1 text-xs">
            <span className="text-[10px] text-neutral-400 font-medium">Screen:</span>
            <select
              value={currentScreen}
              onChange={(e) => setCurrentScreen(e.target.value as ScreenId)}
              className="bg-transparent text-white font-bold text-xs focus:outline-none cursor-pointer"
            >
              <option value="splash" className="bg-neutral-900">1. Splash</option>
              <option value="auth" className="bg-neutral-900">2. Login / Signup</option>
              <option value="home" className="bg-neutral-900">3. Home</option>
              <option value="start_live" className="bg-neutral-900">4. Start Live</option>
              <option value="platform_select" className="bg-neutral-900">5. Platform Selection</option>
              <option value="stream_settings" className="bg-neutral-900">6. Stream Settings</option>
              <option value="live_preview" className="bg-neutral-900">7. Live Preview</option>
              <option value="live_streaming" className="bg-neutral-900">8. Live Streaming</option>
              <option value="creator_studio" className="bg-neutral-900">9. Creator Studio</option>
              <option value="scenes" className="bg-neutral-900">10. Scenes</option>
              <option value="overlays" className="bg-neutral-900">11. Overlays</option>
              <option value="chat" className="bg-neutral-900">12. Chat</option>
              <option value="game_library" className="bg-neutral-900">13. Game Library</option>
              <option value="stream_history" className="bg-neutral-900">14. Stream History</option>
              <option value="profile" className="bg-neutral-900">15. Profile</option>
              <option value="settings" className="bg-neutral-900">16. Settings</option>
            </select>
          </div>

          {/* Android Kotlin Source Code Explorer Button */}
          <button
            onClick={() => setShowCodeModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white text-xs font-bold shadow-md shadow-rose-600/30 cursor-pointer transition-all"
          >
            <Code2 className="w-4 h-4" />
            <span className="hidden sm:inline">Android Source Code</span>
          </button>
        </div>
      </header>

      {/* Main Device Emulation Stage */}
      <main className="flex-1 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
        <AndroidFrame
          orientation={session.settings.orientation}
          onToggleOrientation={() =>
            setSession((prev) => ({
              ...prev,
              settings: {
                ...prev.settings,
                orientation:
                  prev.settings.orientation === 'landscape' ? 'portrait' : 'landscape',
              },
            }))
          }
          isStreaming={session.isLive}
        >
          {/* Active Screen Display */}
          <div className="flex-1 flex flex-col w-full h-full overflow-hidden">
            {currentScreen === 'splash' && (
              <SplashScreen onContinue={() => setCurrentScreen('auth')} />
            )}

            {currentScreen === 'auth' && (
              <AuthScreen
                onSuccess={(name) => {
                  setStreamerName(name);
                  setCurrentScreen('home');
                }}
                onSkipGuest={() => {
                  setStreamerName('GuestStreamer_4L');
                  setCurrentScreen('home');
                }}
              />
            )}

            {currentScreen === 'home' && (
              <HomeScreen
                onGoLive={handleGoLiveStart}
                onNavigate={(screen) => setCurrentScreen(screen)}
                games={games}
                recentStreams={history}
                onSelectGame={(game) =>
                  setSession((prev) => ({ ...prev, selectedGame: game }))
                }
              />
            )}

            {currentScreen === 'start_live' && (
              <StartLiveScreen
                onBack={() => setCurrentScreen('home')}
                onNext={() => setCurrentScreen('platform_select')}
                title={session.title}
                setTitle={(title) => setSession((prev) => ({ ...prev, title }))}
                description={session.description}
                setDescription={(description) =>
                  setSession((prev) => ({ ...prev, description }))
                }
                privacy={session.privacy}
                setPrivacy={(privacy) => setSession((prev) => ({ ...prev, privacy }))}
                tags={session.tags}
                setTags={(tags) => setSession((prev) => ({ ...prev, tags }))}
                selectedGame={session.selectedGame}
                setSelectedGame={(game) =>
                  setSession((prev) => ({ ...prev, selectedGame: game }))
                }
                games={games}
              />
            )}

            {currentScreen === 'platform_select' && (
              <PlatformSelectionScreen
                onBack={() => setCurrentScreen('start_live')}
                onNext={() => setCurrentScreen('stream_settings')}
                platforms={platforms}
                selectedPlatforms={session.selectedPlatforms}
                onTogglePlatform={handleTogglePlatform}
                onUpdateCustomRtmp={handleUpdateCustomRtmp}
              />
            )}

            {currentScreen === 'stream_settings' && (
              <StreamSettingsScreen
                onBack={() => setCurrentScreen('platform_select')}
                onNext={() => setCurrentScreen('live_preview')}
                settings={session.settings}
                onUpdateSettings={(newSettings) =>
                  setSession((prev) => ({
                    ...prev,
                    settings: { ...prev.settings, ...newSettings },
                  }))
                }
              />
            )}

            {currentScreen === 'live_preview' && (
              <LivePreviewScreen
                onBack={() => setCurrentScreen('stream_settings')}
                onStartLive={handleStartLiveConfirm}
                session={session}
                overlay={overlay}
                onEditSettings={() => setCurrentScreen('stream_settings')}
              />
            )}

            {currentScreen === 'live_streaming' && (
              <LiveStreamingScreen
                session={session}
                overlay={overlay}
                onEndStream={handleEndStream}
                onToggleMic={() =>
                  setSession((prev) => ({ ...prev, isMicMuted: !prev.isMicMuted }))
                }
                onToggleCam={() =>
                  setSession((prev) => ({ ...prev, isCamHidden: !prev.isCamHidden }))
                }
                onTogglePause={() =>
                  setSession((prev) => ({ ...prev, isPaused: !prev.isPaused }))
                }
                onNavigateScenes={() => setCurrentScreen('scenes')}
                onNavigateStudio={() => setCurrentScreen('creator_studio')}
              />
            )}

            {currentScreen === 'creator_studio' && (
              <CreatorStudioScreen
                onBack={() => setCurrentScreen('home')}
                isLive={session.isLive}
              />
            )}

            {currentScreen === 'scenes' && (
              <ScenesScreen
                onBack={() => setCurrentScreen('home')}
                scenes={scenes}
                activeSceneId={session.activeSceneId}
                onSelectScene={(id) =>
                  setSession((prev) => ({ ...prev, activeSceneId: id }))
                }
                isLive={session.isLive}
              />
            )}

            {currentScreen === 'overlays' && (
              <OverlaysScreen
                onBack={() => setCurrentScreen('home')}
                overlay={overlay}
                onUpdateOverlay={(updated) =>
                  setOverlay((prev) => ({ ...prev, ...updated }))
                }
              />
            )}

            {currentScreen === 'chat' && (
              <ChatScreen onBack={() => setCurrentScreen('home')} isLive={session.isLive} />
            )}

            {currentScreen === 'game_library' && (
              <GameLibraryScreen
                onBack={() => setCurrentScreen('home')}
                games={games}
                selectedGame={session.selectedGame}
                onSelectGame={(game) =>
                  setSession((prev) => ({ ...prev, selectedGame: game }))
                }
                onStartLiveWithGame={(game) => {
                  setSession((prev) => ({ ...prev, selectedGame: game }));
                  setCurrentScreen('start_live');
                }}
              />
            )}

            {currentScreen === 'stream_history' && (
              <StreamHistoryScreen
                onBack={() => setCurrentScreen('home')}
                history={history}
              />
            )}

            {currentScreen === 'profile' && (
              <ProfileScreen
                onBack={() => setCurrentScreen('home')}
                platforms={platforms}
                streamerName={streamerName}
              />
            )}

            {currentScreen === 'settings' && (
              <SettingsScreen
                onBack={() => setCurrentScreen('home')}
                settings={session.settings}
                onUpdateSettings={(newSettings) =>
                  setSession((prev) => ({
                    ...prev,
                    settings: { ...prev.settings, ...newSettings },
                  }))
                }
                onOpenSourceInspector={() => setShowCodeModal(true)}
              />
            )}
          </div>

          {/* Persistent Android Bottom Nav (When in main navigation screens) */}
          {shouldShowBottomNav && (
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={(screen) => setCurrentScreen(screen)}
            />
          )}
        </AndroidFrame>
      </main>

      {/* Code Inspector & Architecture Modal */}
      <CodeInspectorModal
        isOpen={showCodeModal}
        onClose={() => setShowCodeModal(false)}
      />
    </div>
  );
}
