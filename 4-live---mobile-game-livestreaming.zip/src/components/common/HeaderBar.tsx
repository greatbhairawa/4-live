import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  title,
  subtitle,
  onBack,
  rightAction,
}) => {
  return (
    <div className="h-13 px-4 flex items-center justify-between border-b border-neutral-800/80 bg-neutral-950/90 backdrop-blur-md shrink-0 z-40">
      <div className="flex items-center gap-2.5 overflow-hidden">
        {onBack && (
          <button
            onClick={onBack}
            className="p-1.5 -ml-1 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800/80 transition-colors"
            title="Go Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}
        <div className="truncate">
          <h1 className="text-sm font-bold text-neutral-100 tracking-tight leading-none truncate">
            {title}
          </h1>
          {subtitle && (
            <p className="text-[10px] text-neutral-400 mt-0.5 truncate font-medium">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      {rightAction && <div className="flex items-center gap-1.5">{rightAction}</div>}
    </div>
  );
};
