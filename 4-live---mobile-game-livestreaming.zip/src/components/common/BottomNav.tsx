import React from 'react';
import { Home, Layers, BarChart3, User, Gamepad2 } from 'lucide-react';
import { ScreenId } from '../../types/stream';

interface BottomNavProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  const tabs = [
    { id: 'home' as ScreenId, label: 'Home', icon: Home },
    { id: 'game_library' as ScreenId, label: 'Games', icon: Gamepad2 },
    { id: 'scenes' as ScreenId, label: 'Studio', icon: Layers },
    { id: 'creator_studio' as ScreenId, label: 'Analytics', icon: BarChart3 },
    { id: 'profile' as ScreenId, label: 'Profile', icon: User },
  ];

  return (
    <div className="h-14 px-2 bg-neutral-950/95 border-t border-neutral-800/80 backdrop-blur-lg flex items-center justify-around shrink-0 z-40">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentScreen === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onNavigate(tab.id)}
            className={`flex flex-col items-center justify-center w-14 py-1 rounded-xl transition-all cursor-pointer ${
              isActive
                ? 'text-rose-500 font-bold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <div className="relative">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {isActive && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.8)]" />
              )}
            </div>
            <span className="text-[10px] tracking-tight mt-1">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
};
