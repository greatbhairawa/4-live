import React, { useState } from 'react';
import {
  X,
  FileCode,
  Shield,
  Layers,
  Terminal,
  Copy,
  Check,
  Cpu,
  Smartphone,
  ExternalLink,
} from 'lucide-react';

interface CodeInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeInspectorModal: React.FC<CodeInspectorModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<
    'manifest' | 'engine' | 'service' | 'security' | 'gradle' | 'instructions'
  >('engine');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const codeSnippets = {
    manifest: `<!-- AndroidManifest.xml (4 LIVE) -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.fourlive.app">

    <!-- Broadcast & Network -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Audio: Mic commentary & Android 10+ Internal game audio -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <!-- Facecam Picture-in-Picture -->
    <uses-permission android:name="android.permission.CAMERA" />

    <!-- Foreground Services for persistent background game capture -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" />

    <!-- In-Game Floating HUD Overlay Bubble -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <application
        android:name=".FourLiveApplication"
        android:theme="@style/Theme.FourLive">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Broadcast Engine Foreground Service -->
        <service
            android:name=".core.service.StreamForegroundService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="mediaProjection|microphone|camera" />
    </application>
</manifest>`,

    engine: `// com/fourlive/app/core/engine/StreamEngine.kt
package com.fourlive.app.core.engine

import android.content.Context
import android.content.Intent
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.StateFlow

interface StreamEngine {
    val streamState: StateFlow<StreamState>
    val metrics: StateFlow<StreamMetrics>

    fun initialize(context: Context, projectionResultCode: Int, projectionData: Intent)
    fun startBroadcast(config: StreamConfig, rtmpUrl: String, streamKey: String)
    fun pauseBroadcast()
    fun resumeBroadcast()
    fun stopBroadcast()
    fun toggleMicrophone(enabled: Boolean)
    fun toggleCamera(enabled: Boolean)
    fun cleanup()
}

class DefaultStreamEngine(private val context: Context) : StreamEngine {
    // 1. MediaProjection Screen Capture Setup
    // 2. Dual Audio Capture: Microphone AudioRecord + Android 10 AudioPlaybackCapture
    // 3. Hardware H.264 Video Encoder via MediaCodec Surface
    // 4. Adaptive Bitrate Monitor via ConnectivityManager link bandwidth
    // 5. Automatic teardown on MediaProjection.Callback.onStop()
}`,

    service: `// com/fourlive/app/core/service/StreamForegroundService.kt
package com.fourlive.app.core.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat

class StreamForegroundService : Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, "4live_channel")
            .setContentTitle("4 LIVE is broadcasting your screen")
            .setContentText("Playing Mobile Game • 1080p 60fps")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            startForeground(4040, notification, types)
        }
        return START_STICKY
    }
}`,

    security: `// com/fourlive/app/core/security/SecureStorage.kt
package com.fourlive.app.core.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureStorage(context: Context) {
    // MasterKey generated via Android KeyStore (AES256_GCM)
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    // EncryptedSharedPreferences ensures stream keys & tokens
    // are NEVER written to disk in plain text.
    private val securePrefs = EncryptedSharedPreferences.create(
        context,
        "fourlive_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveStreamKey(platformId: String, streamKey: String) {
        securePrefs.edit().putString("key_$platformId", streamKey).apply()
    }
}`,

    gradle: `// app/build.gradle.kts
dependencies {
    // Jetpack Compose & Material 3
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // CameraX (Facecam Picture-in-Picture)
    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")

    // Security (EncryptedSharedPreferences)
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}`,

    instructions: `### How to Build & Test the 4 LIVE Native Android App

1. **Prerequisites**:
   - Android Studio Ladybug (2024.2+) or newer
   - JDK 17 (set in Android Studio Settings -> Build -> Gradle -> Gradle JDK)
   - Android SDK 35 (compileSdk 35, minSdk 26)

2. **Open Project**:
   - Open Android Studio
   - Select "Open Existing Project" and choose the \`/android\` folder in this project root.

3. **Sync Gradle**:
   - Click "Sync Project with Gradle Files"
   - Gradle will resolve Compose BOM, CameraX, and Security-Crypto dependencies.

4. **Run on Physical Device or Emulator**:
   - Connect an Android device (Android 10+ recommended for game internal audio capture)
   - Enable USB Debugging in Developer Options
   - Select your device in the toolbar and click "Run 'app'" (Shift + F10)

5. **Test Screen Broadcast Flow**:
   - Grant Audio & Camera permissions when prompted
   - Choose game category (e.g. PUBG Mobile or Full Screen Cast)
   - Tap "START LIVE BROADCAST"
   - Accept the Android MediaProjection consent prompt
   - 4 LIVE will start the Foreground Service and broadcast RTMP video with real-time stats HUD!`,
  };

  const copyCode = () => {
    navigator.clipboard?.writeText(codeSnippets[activeTab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center text-white font-bold">
              4L
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
                <span>4 LIVE Android Native Architecture</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Ready to Build
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Kotlin • Jetpack Compose • Material 3 • MediaProjection • Security Keystore
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 p-2 bg-neutral-950/70 border-b border-neutral-800 overflow-x-auto text-xs">
          {[
            { id: 'engine', label: 'StreamEngine.kt', icon: Cpu },
            { id: 'service', label: 'ForegroundService.kt', icon: Smartphone },
            { id: 'security', label: 'SecureStorage.kt', icon: Shield },
            { id: 'manifest', label: 'AndroidManifest.xml', icon: FileCode },
            { id: 'gradle', label: 'build.gradle.kts', icon: Layers },
            { id: 'instructions', label: 'Build APK Guide', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl font-mono text-xs transition-colors shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-rose-500 text-white font-bold shadow'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}

          <button
            onClick={copyCode}
            className="ml-auto flex items-center gap-1 px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold shrink-0 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>

        {/* Code Content View */}
        <div className="flex-1 p-4 overflow-y-auto bg-neutral-950 font-mono text-xs text-neutral-300 leading-relaxed selection:bg-rose-500 selection:text-white">
          <pre className="whitespace-pre-wrap">{codeSnippets[activeTab]}</pre>
        </div>

        {/* Footer */}
        <div className="p-3 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
          <span>Project Root: <code className="text-rose-400">/android</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold cursor-pointer"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
