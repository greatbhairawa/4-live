import React from 'react';
import { HeaderBar } from '../common/HeaderBar';
import {
  User,
  ShieldCheck,
  Award,
  Zap,
  Radio,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Share2,
} from 'lucide-react';
import { PlatformConfig } from '../../types/stream';

interface ProfileScreenProps {
  onBack?: () => void;
  platforms: PlatformConfig[];
  streamerName: string;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onBack,
  platforms,
  streamerName,
}) => {
  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Creator Profile"
        subtitle="Tier, Badges & Connected Accounts"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-4">
        {/* Streamer Profile Header Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-b from-neutral-900 to-neutral-950 border border-neutral-800 flex flex-col items-center text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-600/10 rounded-full blur-2xl pointer-events-none" />

          {/* Avatar with glowing ring */}
          <div className="relative mb-3">
            <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-rose-500 shadow-lg shadow-rose-500/20">
              <img
                src="https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80"
                alt="Profile Avatar"
                className="w-full h-full object-cover"
              />
            </div>
            <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-rose-600 text-white text-[9px] font-mono font-bold tracking-wider uppercase border border-neutral-900">
              LVL 28
            </span>
          </div>

          <h2 className="text-base font-extrabold text-white">{streamerName}</h2>
          <p className="text-xs text-rose-400 font-medium">@NeonStriker_4L</p>

          <p className="text-xs text-neutral-400 max-w-[260px] mt-2 leading-relaxed">
            Competitive Mobile FPS & Battle Royale streamer. Playing on 4 LIVE with ultra-low latency.
          </p>

          <div className="flex items-center gap-1.5 mt-3 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>4 LIVE Verified Partner</span>
          </div>
        </div>

        {/* Milestone Stats */}
        <div className="grid grid-cols-3 gap-2 p-3 bg-neutral-900/60 rounded-2xl border border-neutral-800 text-center">
          <div>
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">Total Hours</span>
            <p className="text-sm font-black text-white mt-0.5">142.5h</p>
          </div>
          <div className="border-x border-neutral-800">
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">Followers</span>
            <p className="text-sm font-black text-rose-400 mt-0.5">3,840</p>
          </div>
          <div>
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">Rank Tier</span>
            <p className="text-sm font-black text-cyan-400 mt-0.5">Master</p>
          </div>
        </div>

        {/* Connected Platform Accounts */}
        <div>
          <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider mb-2">
            Connected Broadcast Channels
          </h3>

          <div className="flex flex-col gap-2">
            {platforms.map((p) => (
              <div
                key={p.id}
                className="p-3 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-neutral-800 flex items-center justify-center text-xs font-bold text-white">
                    {p.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-neutral-200">{p.name}</p>
                    <p className="text-[10px] text-neutral-400">
                      {p.connected ? `@${p.username || 'Authorized'}` : 'Not connected'}
                    </p>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    p.connected
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : 'bg-neutral-800 text-neutral-500 border-neutral-700'
                  }`}
                >
                  {p.connected ? 'ACTIVE' : 'LINK'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Badges / Achievements */}
        <div className="p-3 bg-neutral-900/60 rounded-2xl border border-neutral-800">
          <div className="flex items-center gap-2 mb-2">
            <Award className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-bold text-neutral-200">Streamer Achievements</h4>
          </div>
          <div className="flex gap-2 text-[10px]">
            <span className="px-2.5 py-1 rounded-xl bg-neutral-950 border border-neutral-800 text-amber-400 font-bold">
              🏆 100h Club
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-neutral-950 border border-neutral-800 text-rose-400 font-bold">
              ⚡ 500+ CCU Peak
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-neutral-950 border border-neutral-800 text-cyan-400 font-bold">
              🎯 1080p Master
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
