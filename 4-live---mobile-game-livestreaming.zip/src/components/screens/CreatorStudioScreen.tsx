import React, { useState } from 'react';
import { HeaderBar } from '../common/HeaderBar';
import {
  BarChart3,
  Volume2,
  Shield,
  Zap,
  Sparkles,
  Users,
  Flame,
  MessageSquare,
  Bot,
  Bell,
  Check,
} from 'lucide-react';

interface CreatorStudioScreenProps {
  onBack?: () => void;
  isLive?: boolean;
}

export const CreatorStudioScreen: React.FC<CreatorStudioScreenProps> = ({
  onBack,
  isLive = false,
}) => {
  const [activeAlert, setActiveAlert] = useState<string | null>(null);
  const [slowMode, setSlowMode] = useState(false);
  const [subOnly, setSubOnly] = useState(false);
  const [filterLinks, setFilterLinks] = useState(true);

  const soundboard = [
    { id: 'victory', name: 'Victory Horn', icon: '🎺', color: '#10B981' },
    { id: 'gg', name: 'GG Chime', icon: '🏆', color: '#F43F5E' },
    { id: 'airhorn', name: 'Hype Airhorn', icon: '🚨', color: '#06B6D4' },
    { id: 'level', name: 'Level Up', icon: '⭐', color: '#F59E0B' },
  ];

  const triggerSound = (name: string) => {
    setActiveAlert(`Alert Broadcasted: "${name}" played on live stream feed!`);
    setTimeout(() => setActiveAlert(null), 3000);
  };

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Creator Studio"
        subtitle="Live Analytics & Interactive Tools"
        onBack={onBack}
        rightAction={
          isLive ? (
            <span className="flex items-center gap-1 text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
              ON AIR
            </span>
          ) : undefined
        }
      />

      <div className="p-4 flex-1 flex flex-col gap-4">
        {/* Real-time Alert Toast */}
        {activeAlert && (
          <div className="p-2.5 rounded-xl bg-gradient-to-r from-rose-600/90 to-amber-500/90 text-white text-xs font-bold flex items-center justify-between shadow-lg animate-bounce">
            <span className="truncate">{activeAlert}</span>
            <Sparkles className="w-4 h-4 shrink-0" />
          </div>
        )}

        {/* Live Performance Overview */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              <span>Broadcast Analytics</span>
            </h3>
            <span className="text-[10px] text-neutral-400 font-mono">Live telemetry</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold uppercase">Peak Viewers</span>
              <p className="text-lg font-black text-rose-400 mt-0.5">684</p>
              <span className="text-[9px] text-emerald-400 font-bold mt-0.5 block">+34% vs avg</span>
            </div>

            <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold uppercase">Chat Velocity</span>
              <p className="text-lg font-black text-cyan-400 mt-0.5">42 msgs/min</p>
              <span className="text-[9px] text-neutral-400 font-medium mt-0.5 block">High engagement</span>
            </div>

            <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold uppercase">Watch Time</span>
              <p className="text-lg font-black text-white mt-0.5">18.4 mins</p>
              <span className="text-[9px] text-emerald-400 font-bold mt-0.5 block">Avg per viewer</span>
            </div>

            <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold uppercase">Stream Health</span>
              <p className="text-lg font-black text-emerald-400 mt-0.5">100%</p>
              <span className="text-[9px] text-emerald-400 font-mono mt-0.5 block">0 dropped frames</span>
            </div>
          </div>
        </div>

        {/* Live Soundboard & SFX */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-rose-400" />
              <span>Live Soundboard</span>
            </h3>
            <span className="text-[10px] text-neutral-400">Trigger on stream</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {soundboard.map((item) => (
              <button
                key={item.id}
                onClick={() => triggerSound(item.name)}
                className="flex items-center gap-2.5 p-3 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 transition-all cursor-pointer text-left active:scale-95"
              >
                <span className="text-xl">{item.icon}</span>
                <div>
                  <p className="text-xs font-bold text-neutral-200">{item.name}</p>
                  <p className="text-[9px] text-neutral-400">Play SFX Audio</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Stream Chat Moderation */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>Chat Moderation Shield</span>
            </h3>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
              <div>
                <p className="text-xs font-bold text-neutral-200">Slow Mode (10s delay)</p>
                <p className="text-[10px] text-neutral-400">Prevents rapid spam during hype moments</p>
              </div>
              <button
                onClick={() => setSlowMode(!slowMode)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  slowMode ? 'bg-rose-500' : 'bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    slowMode ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
              <div>
                <p className="text-xs font-bold text-neutral-200">Followers-Only Chat</p>
                <p className="text-[10px] text-neutral-400">Restricts chat to verified followers</p>
              </div>
              <button
                onClick={() => setSubOnly(!subOnly)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  subOnly ? 'bg-rose-500' : 'bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    subOnly ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
              <div>
                <p className="text-xs font-bold text-neutral-200">Block Hyperlinks & Phishing</p>
                <p className="text-[10px] text-neutral-400">Auto-hide unverified external URLs</p>
              </div>
              <button
                onClick={() => setFilterLinks(!filterLinks)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  filterLinks ? 'bg-emerald-500' : 'bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    filterLinks ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Bot Commands */}
        <div className="p-3 bg-neutral-900/60 rounded-2xl border border-neutral-800">
          <div className="flex items-center gap-2 mb-2">
            <Bot className="w-4 h-4 text-purple-400" />
            <h4 className="text-xs font-bold text-neutral-200">4 LIVE Stream Bot Commands</h4>
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono">
            <div className="bg-neutral-950 p-2 rounded-xl border border-neutral-800 text-center">
              <span className="text-rose-400 font-bold">!socials</span>
              <p className="text-[9px] text-neutral-500 mt-0.5">Links</p>
            </div>
            <div className="bg-neutral-950 p-2 rounded-xl border border-neutral-800 text-center">
              <span className="text-cyan-400 font-bold">!discord</span>
              <p className="text-[9px] text-neutral-500 mt-0.5">Community</p>
            </div>
            <div className="bg-neutral-950 p-2 rounded-xl border border-neutral-800 text-center">
              <span className="text-emerald-400 font-bold">!specs</span>
              <p className="text-[9px] text-neutral-500 mt-0.5">Phone & FPS</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
