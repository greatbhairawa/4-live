import React, { useState } from 'react';
import { HeaderBar } from '../common/HeaderBar';
import { StreamSettings } from '../../types/stream';
import {
  Settings as SettingsIcon,
  Cpu,
  Volume2,
  ShieldCheck,
  Smartphone,
  BellOff,
  Trash2,
  Info,
  ChevronRight,
  Code2,
} from 'lucide-react';

interface SettingsScreenProps {
  onBack?: () => void;
  settings: StreamSettings;
  onUpdateSettings: (newSettings: Partial<StreamSettings>) => void;
  onOpenSourceInspector: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onBack,
  settings,
  onUpdateSettings,
  onOpenSourceInspector,
}) => {
  const [dndEnabled, setDndEnabled] = useState(true);
  const [floatingOverlayPerm, setFloatingOverlayPerm] = useState(true);
  const [clearedToast, setClearedToast] = useState(false);

  const handleClearKeys = () => {
    setClearedToast(true);
    setTimeout(() => setClearedToast(false), 2500);
  };

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Application Settings"
        subtitle="Encoder, Permissions & Keystore"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-4">
        {clearedToast && (
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-bold flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>Encrypted Keystore credentials cleared successfully!</span>
          </div>
        )}

        {/* Developer & Architecture Inspector Card */}
        <div
          onClick={onOpenSourceInspector}
          className="p-3.5 rounded-2xl bg-gradient-to-r from-rose-900/30 via-neutral-900 to-neutral-900 border border-rose-500/40 cursor-pointer hover:border-rose-500 transition-all flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Android Source Code Explorer</h4>
              <p className="text-[10px] text-neutral-400">View Kotlin Jetpack Compose & Gradle files</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </div>

        {/* Video Codec Settings */}
        <div>
          <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-rose-400" />
            <span>Video Encoding Pipeline</span>
          </h3>

          <div className="flex flex-col gap-2">
            <div className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-neutral-200">Hardware Acceleration</p>
                <p className="text-[10px] text-neutral-400">MediaCodec direct GPU surface encoding</p>
              </div>
              <button
                onClick={() =>
                  onUpdateSettings({ hardwareEncoder: !settings.hardwareEncoder })
                }
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.hardwareEncoder ? 'bg-rose-500' : 'bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.hardwareEncoder ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-neutral-200">Keyframe Interval (GOP)</p>
                <p className="text-[10px] text-neutral-400">Required by YouTube & Twitch</p>
              </div>
              <div className="flex gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs font-bold">
                {[1, 2].map((sec) => (
                  <button
                    key={sec}
                    onClick={() => onUpdateSettings({ keyframeIntervalSeconds: sec })}
                    className={`px-2.5 py-1 rounded-lg transition-colors ${
                      settings.keyframeIntervalSeconds === sec
                        ? 'bg-rose-600 text-white'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Audio Pipeline Settings */}
        <div>
          <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Audio Configuration</span>
          </h3>

          <div className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-neutral-200">AAC Audio Bitrate</p>
              <p className="text-[10px] text-neutral-400">Stereo 48.0 kHz sampling</p>
            </div>
            <div className="flex gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs font-bold">
              {[128, 160, 192].map((rate) => (
                <button
                  key={rate}
                  onClick={() => onUpdateSettings({ audioBitrateKbps: rate })}
                  className={`px-2 py-1 rounded-lg text-[11px] font-mono transition-colors ${
                    settings.audioBitrateKbps === rate
                      ? 'bg-cyan-500 text-black font-extrabold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {rate}k
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Android System Permissions & Gameplay Integration */}
        <div>
          <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Android System Permissions</span>
          </h3>

          <div className="flex flex-col gap-2">
            <div className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-neutral-200">In-Game Floating HUD Widget</p>
                <p className="text-[10px] text-neutral-400">SYSTEM_ALERT_WINDOW bubble control</p>
              </div>
              <button
                onClick={() => setFloatingOverlayPerm(!floatingOverlayPerm)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  floatingOverlayPerm ? 'bg-emerald-500' : 'bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    floatingOverlayPerm ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-neutral-200">Auto Do Not Disturb (DND)</p>
                <p className="text-[10px] text-neutral-400">Block popup calls & SMS alerts while live</p>
              </div>
              <button
                onClick={() => setDndEnabled(!dndEnabled)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  dndEnabled ? 'bg-rose-500' : 'bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    dndEnabled ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Security & Keystore management */}
        <div>
          <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Keystore & Credential Privacy</span>
          </h3>

          <div className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-neutral-200">Reset Saved Stream Keys</p>
              <p className="text-[10px] text-neutral-400">Wipes encrypted keystore partition</p>
            </div>
            <button
              onClick={handleClearKeys}
              className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-rose-600 hover:text-white text-rose-400 text-xs font-bold border border-neutral-700 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Keys</span>
            </button>
          </div>
        </div>

        {/* App Info Footer */}
        <div className="p-3 rounded-2xl bg-neutral-900/40 border border-neutral-800 text-center text-[10px] text-neutral-500 font-mono">
          <p className="text-neutral-400 font-bold">4 LIVE for Android • Version 1.0.0 (Build 104)</p>
          <p className="mt-0.5">Kotlin • Jetpack Compose • Material 3 • MediaProjection</p>
        </div>
      </div>
    </div>
  );
};
