import React, { useState, useEffect } from 'react';
import { StreamSessionState, OverlayConfig, ChatMessage } from '../../types/stream';
import {
  Radio,
  Eye,
  Clock,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  Pause,
  Play,
  PhoneOff,
  MessageSquare,
  Sparkles,
  Sliders,
  Layers,
  Send,
  X,
  Share2,
  CheckCircle,
} from 'lucide-react';

interface LiveStreamingScreenProps {
  session: StreamSessionState;
  overlay: OverlayConfig;
  onEndStream: () => void;
  onToggleMic: () => void;
  onToggleCam: () => void;
  onTogglePause: () => void;
  onNavigateScenes: () => void;
  onNavigateStudio: () => void;
}

export const LiveStreamingScreen: React.FC<LiveStreamingScreenProps> = ({
  session,
  overlay,
  onEndStream,
  onToggleMic,
  onToggleCam,
  onTogglePause,
  onNavigateScenes,
  onNavigateStudio,
}) => {
  const [showEndModal, setShowEndModal] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [showChatOverlay, setShowChatOverlay] = useState(true);
  const [showFloatingBubble, setShowFloatingBubble] = useState(true);

  // Dynamic live stats
  const [seconds, setSeconds] = useState(session.liveDurationSeconds || 42);
  const [bitrate, setBitrate] = useState(5480);
  const [fps, setFps] = useState(59.9);
  const [viewers, setViewers] = useState(482);
  const [droppedFrames, setDroppedFrames] = useState(0);

  // Dynamic interactive live chat
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'KryptoGamer',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=60&auto=format&fit=crop&q=80',
      message: 'Insane clutch in the last round! 🔥🔥🔥',
      timestamp: 'Just now',
      isSub: true,
      color: '#06B6D4',
    },
    {
      id: 'm2',
      sender: 'ViperX',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=60&auto=format&fit=crop&q=80',
      message: '1080p 60fps stream is buttery smooth bro',
      timestamp: '10s ago',
      color: '#10B981',
    },
    {
      id: 'm3',
      sender: 'SarahGaming_Mod',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&auto=format&fit=crop&q=80',
      message: 'Welcome everyone! Tap like & subscribe for 4 LIVE team!',
      timestamp: '30s ago',
      isMod: true,
      color: '#F43F5E',
    },
  ]);
  const [newMsg, setNewMsg] = useState('');

  // Live timer & telemetry ticker
  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds((s) => s + 1);
      // Realistic live fluctuation
      setBitrate((b) => Math.floor(5200 + Math.random() * 600));
      setFps(+(59.5 + Math.random() * 0.5).toFixed(1));
      if (Math.random() > 0.6) {
        setViewers((v) => v + (Math.random() > 0.4 ? 1 : -1));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (totalSeconds: number) => {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    if (h > 0) {
      return `${h}:${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    }
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMsg.trim()) return;

    setMessages((prev) => [
      ...prev,
      {
        id: `m-${Date.now()}`,
        sender: 'You (Streamer)',
        avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=60&auto=format&fit=crop&q=80',
        message: newMsg.trim(),
        timestamp: 'Just now',
        isMod: true,
        color: '#F43F5E',
      },
    ]);
    setNewMsg('');
  };

  const confirmEndStream = () => {
    setShowEndModal(false);
    setShowSummaryModal(true);
  };

  return (
    <div className="relative flex-1 flex flex-col bg-neutral-950 text-white overflow-hidden">
      {/* Top Floating HUD: Live Status & Telemetry */}
      <div className="h-12 px-3 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80 flex items-center justify-between shrink-0 z-30">
        <div className="flex items-center gap-2">
          {/* LIVE Pulsing Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-600 text-white font-mono text-[10px] font-black tracking-wider uppercase shadow-lg shadow-rose-600/40">
            <span className="w-2 h-2 rounded-full bg-white animate-ping" />
            <span>LIVE</span>
          </div>

          {/* Duration Clock */}
          <div className="flex items-center gap-1 text-[11px] font-mono text-neutral-300 font-bold bg-neutral-900 px-2 py-0.5 rounded-lg border border-neutral-800">
            <Clock className="w-3 h-3 text-neutral-400" />
            <span>{formatTime(seconds)}</span>
          </div>
        </div>

        {/* Telemetry Stats: Bitrate, FPS, Viewers */}
        <div className="flex items-center gap-2 text-[10px] font-mono">
          <div className="flex items-center gap-1 text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
            <Eye className="w-3 h-3" />
            <span className="font-bold">{viewers}</span>
          </div>

          <div className="hidden sm:flex items-center gap-1 text-neutral-300 bg-neutral-900 px-2 py-0.5 rounded-lg border border-neutral-800">
            <span>{fps} FPS</span>
          </div>

          <div className="flex items-center gap-1 text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-lg border border-cyan-500/20 font-bold">
            <span>{bitrate} kb/s</span>
          </div>
        </div>
      </div>

      {/* Main Stream Screen Area (Game Display + PIP Facecam + Overlays) */}
      <div className="relative flex-1 w-full bg-neutral-900 overflow-hidden flex flex-col justify-between">
        
        {/* Active Game Feed / Background */}
        <div className="absolute inset-0 z-0">
          <img
            src={session.selectedGame.bannerUrl}
            alt={session.selectedGame.name}
            className="w-full h-full object-cover filter contrast-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />

          {/* Paused / BRB Screen Overlay */}
          {session.isPaused && (
            <div className="absolute inset-0 bg-black/90 backdrop-blur-md z-30 flex flex-col items-center justify-center text-center p-6">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-3">
                <Pause className="w-8 h-8" />
              </div>
              <h3 className="text-base font-extrabold text-white">BRB / PRIVACY SHIELD ACTIVE</h3>
              <p className="text-xs text-neutral-400 mt-1 max-w-[240px]">
                Screen capture and mic audio are muted for privacy while entering passwords or switching apps.
              </p>
              <button
                onClick={onTogglePause}
                className="mt-4 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs cursor-pointer flex items-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>Resume Game Feed</span>
              </button>
            </div>
          )}
        </div>

        {/* Studio Active Overlay Frame */}
        {overlay.borderStyle !== 'none' && !session.isPaused && (
          <div className="absolute inset-0 pointer-events-none z-10 border-4 border-rose-500/70 shadow-[inset_0_0_20px_rgba(244,63,94,0.3)]">
            <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
            <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
            <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />
          </div>
        )}

        {/* Goal Bar Widget */}
        {overlay.showGoalBar && !session.isPaused && (
          <div className="relative z-20 mx-3 mt-2 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-md border border-neutral-700/80 flex items-center justify-between text-[9px]">
            <span className="text-rose-400 font-bold uppercase">{overlay.goalTitle}</span>
            <div className="flex items-center gap-1.5 font-mono">
              <div className="w-16 h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-rose-500 to-amber-400 rounded-full"
                  style={{ width: `${(overlay.goalCurrent / overlay.goalTarget) * 100}%` }}
                />
              </div>
              <span className="text-neutral-300 font-semibold">{overlay.goalCurrent}/{overlay.goalTarget}</span>
            </div>
          </div>
        )}

        {/* Facecam PIP */}
        {session.settings.cameraEnabled && !session.isCamHidden && !session.isPaused && (
          <div
            className={`absolute z-20 w-16 h-16 rounded-xl overflow-hidden border-2 border-rose-500 bg-neutral-900 shadow-xl ${
              overlay.camPosition === 'top_left'
                ? 'top-8 left-3'
                : overlay.camPosition === 'bottom_left'
                ? 'bottom-20 left-3'
                : overlay.camPosition === 'bottom_right'
                ? 'bottom-20 right-3'
                : 'top-8 right-3'
            }`}
          >
            <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-tr from-neutral-800 to-neutral-900 text-center p-1">
              <Camera className="w-4 h-4 text-rose-400 mb-0.5" />
              <span className="text-[7px] font-mono text-emerald-400">FACECAM</span>
            </div>
          </div>
        )}

        {/* In-Game Floating Pill Overlay HUD Simulation (Simulates Android SYSTEM_ALERT_WINDOW bubble) */}
        {showFloatingBubble && (
          <div className="absolute top-14 right-3 z-30 bg-neutral-950/90 border border-neutral-700/80 backdrop-blur-md rounded-2xl p-1.5 shadow-2xl flex flex-col gap-1.5">
            <span className="text-[8px] font-mono text-neutral-400 text-center font-bold px-1">
              4L HUD
            </span>
            <button
              onClick={onToggleMic}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                session.isMicMuted ? 'bg-rose-500/20 text-rose-400' : 'bg-neutral-800 text-white'
              }`}
              title="Mute Mic"
            >
              {session.isMicMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={onTogglePause}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                session.isPaused ? 'bg-amber-500/20 text-amber-400' : 'bg-neutral-800 text-white'
              }`}
              title="Pause Feed (BRB)"
            >
              <Pause className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowChatOverlay(!showChatOverlay)}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                showChatOverlay ? 'bg-cyan-500/20 text-cyan-400' : 'bg-neutral-800 text-neutral-400'
              }`}
              title="Toggle Live Chat"
            >
              <MessageSquare className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Transparent Interactive Chat Overlay */}
        {showChatOverlay && !session.isPaused && (
          <div className="relative z-20 mx-3 mb-2 flex flex-col gap-1.5 max-h-36 overflow-y-auto no-scrollbar pointer-events-auto">
            {messages.map((m) => (
              <div
                key={m.id}
                className="flex items-start gap-1.5 bg-black/70 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-neutral-800/80 max-w-[85%]"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    {m.isMod && (
                      <span className="text-[8px] font-bold bg-rose-500/20 text-rose-400 px-1 rounded border border-rose-500/30">
                        MOD
                      </span>
                    )}
                    {m.isSub && (
                      <span className="text-[8px] font-bold bg-cyan-500/20 text-cyan-400 px-1 rounded border border-cyan-500/30">
                        SUB
                      </span>
                    )}
                    <span className="text-[10px] font-bold" style={{ color: m.color || '#fff' }}>
                      {m.sender}
                    </span>
                  </div>
                  <p className="text-[10px] text-neutral-200 leading-tight mt-0.5 break-words">
                    {m.message}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Streamer Quick Chat Input */}
      <form
        onSubmit={handleSendChat}
        className="px-3 py-1.5 bg-neutral-950/95 border-t border-neutral-800/80 flex items-center gap-2 shrink-0 z-30"
      >
        <input
          type="text"
          value={newMsg}
          onChange={(e) => setNewMsg(e.target.value)}
          placeholder="Send message to live audience..."
          className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 text-[11px] text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
        />
        <button
          type="submit"
          className="p-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>

      {/* Bottom Live Controls Dock */}
      <div className="px-3 py-2 bg-neutral-950 border-t border-neutral-900 flex items-center justify-between shrink-0 z-30">
        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleMic}
            className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
              session.isMicMuted
                ? 'bg-rose-500/15 border-rose-500 text-rose-400'
                : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white'
            }`}
            title="Toggle Microphone"
          >
            {session.isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <button
            onClick={onToggleCam}
            className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
              session.isCamHidden
                ? 'bg-rose-500/15 border-rose-500 text-rose-400'
                : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white'
            }`}
            title="Toggle Facecam"
          >
            {session.isCamHidden ? <CameraOff className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
          </button>

          <button
            onClick={onTogglePause}
            className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
              session.isPaused
                ? 'bg-amber-500/20 border-amber-500 text-amber-400'
                : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white'
            }`}
            title="Pause Screen Capture (Privacy BRB)"
          >
            {session.isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </button>

          <button
            onClick={onNavigateScenes}
            className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-purple-400 hover:text-purple-300 transition-colors"
            title="Scenes Switcher"
          >
            <Layers className="w-4 h-4" />
          </button>

          <button
            onClick={onNavigateStudio}
            className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-cyan-400 hover:text-cyan-300 transition-colors"
            title="Creator Studio & Alerts"
          >
            <Sparkles className="w-4 h-4" />
          </button>
        </div>

        {/* Red End Broadcast Action Button */}
        <button
          onClick={() => setShowEndModal(true)}
          className="px-3.5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-rose-600/30 cursor-pointer active:scale-95 transition-all"
        >
          <PhoneOff className="w-3.5 h-3.5" />
          <span>END STREAM</span>
        </button>
      </div>

      {/* End Stream Confirmation Modal */}
      {showEndModal && (
        <div className="absolute inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl text-center flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-500 flex items-center justify-center mb-3">
              <PhoneOff className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-extrabold text-white">End Broadcast Now?</h3>
            <p className="text-xs text-neutral-400 mt-1 mb-4">
              Your stream to YouTube & Twitch will end. A complete stream performance report will be generated.
            </p>

            <div className="flex gap-2 w-full">
              <button
                onClick={() => setShowEndModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-bold cursor-pointer"
              >
                Keep Live
              </button>
              <button
                onClick={confirmEndStream}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                End & Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stream Post-Broadcast Summary Report Modal */}
      {showSummaryModal && (
        <div className="absolute inset-0 bg-neutral-950 z-50 flex flex-col justify-between p-5 overflow-y-auto">
          <div className="flex flex-col items-center text-center my-auto">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8" />
            </div>

            <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20 mb-2">
              Broadcast Completed Successfully
            </span>

            <h2 className="text-xl font-black text-white">{session.title}</h2>
            <p className="text-xs text-neutral-400 mt-0.5">{session.selectedGame.name}</p>

            {/* Performance Metric Cards */}
            <div className="grid grid-cols-2 gap-3 w-full my-5">
              <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
                <p className="text-[10px] text-neutral-400 uppercase font-semibold">Duration</p>
                <p className="text-base font-black text-white mt-0.5">{formatTime(seconds)}</p>
              </div>

              <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
                <p className="text-[10px] text-neutral-400 uppercase font-semibold">Peak Viewers</p>
                <p className="text-base font-black text-rose-400 mt-0.5">{viewers + 48}</p>
              </div>

              <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
                <p className="text-[10px] text-neutral-400 uppercase font-semibold">Avg Bitrate</p>
                <p className="text-base font-black text-cyan-400 mt-0.5">5,420 Kbps</p>
              </div>

              <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
                <p className="text-[10px] text-neutral-400 uppercase font-semibold">Dropped Frames</p>
                <p className="text-base font-black text-emerald-400 mt-0.5">0 (0.0%)</p>
              </div>
            </div>

            <p className="text-xs text-neutral-400">
              VOD recording has been securely packaged and synced to your connected channel.
            </p>
          </div>

          <div className="flex flex-col gap-2 pt-4 border-t border-neutral-900">
            <button
              onClick={onEndStream}
              className="w-full py-3.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 cursor-pointer"
            >
              RETURN TO 4 LIVE HOME
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
