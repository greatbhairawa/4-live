import React from 'react';
import { StreamSettings, Resolution, FpsRate, BitrateMode, OrientationMode } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Video,
  Mic,
  Volume2,
  Camera,
  Smartphone,
  Sliders,
  Cpu,
  ArrowRight,
  Sparkles,
  Info,
} from 'lucide-react';

interface StreamSettingsScreenProps {
  onBack: () => void;
  onNext: () => void;
  settings: StreamSettings;
  onUpdateSettings: (newSettings: Partial<StreamSettings>) => void;
}

export const StreamSettingsScreen: React.FC<StreamSettingsScreenProps> = ({
  onBack,
  onNext,
  settings,
  onUpdateSettings,
}) => {
  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Stream Settings"
        subtitle="Step 3 of 4: Video, Audio & Codec"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-4">
        {/* Resolution Options */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
              <Video className="w-3.5 h-3.5 text-rose-400" />
              <span>Broadcast Resolution</span>
            </label>
            <span className="text-[10px] text-neutral-400 font-mono">
              {settings.resolution === '1080p' ? 'Full HD (1920x1080)' : settings.resolution === '720p' ? 'HD (1280x720)' : 'SD (854x480)'}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {(['480p', '720p', '1080p'] as Resolution[]).map((res) => {
              const isSelected = settings.resolution === res;
              return (
                <button
                  key={res}
                  onClick={() => onUpdateSettings({ resolution: res })}
                  className={`py-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-rose-500/15 border-rose-500 text-white font-bold shadow-md shadow-rose-500/10'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <span className="text-xs">{res}</span>
                  <span className="text-[9px] block text-neutral-500 font-normal">
                    {res === '1080p' ? 'Crisp Pro' : res === '720p' ? 'Balanced' : 'Data Saver'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* FPS & Orientation Row */}
        <div className="grid grid-cols-2 gap-3">
          {/* Framerate */}
          <div>
            <label className="text-xs font-bold text-neutral-200 mb-1.5 block">
              Framerate (FPS)
            </label>
            <div className="grid grid-cols-2 gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
              {([30, 60] as FpsRate[]).map((rate) => (
                <button
                  key={rate}
                  onClick={() => onUpdateSettings({ fps: rate })}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                    settings.fps === rate
                      ? 'bg-rose-600 text-white shadow'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {rate} FPS
                </button>
              ))}
            </div>
          </div>

          {/* Orientation */}
          <div>
            <label className="text-xs font-bold text-neutral-200 mb-1.5 block">
              Orientation
            </label>
            <div className="grid grid-cols-2 gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
              {(['landscape', 'portrait'] as OrientationMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onUpdateSettings({ orientation: mode })}
                  className={`py-1.5 rounded-lg text-xs font-bold capitalize transition-all ${
                    settings.orientation === mode
                      ? 'bg-rose-600 text-white shadow'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {mode === 'landscape' ? 'Land' : 'Port'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bitrate Control */}
        <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <label className="text-xs font-bold text-neutral-200">Bitrate</label>
            </div>
            <div className="flex items-center gap-1 bg-neutral-950 px-2 py-0.5 rounded-lg border border-neutral-800">
              {(['auto', 'manual'] as BitrateMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onUpdateSettings({ bitrateMode: mode })}
                  className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                    settings.bitrateMode === mode
                      ? 'bg-rose-500 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {settings.bitrateMode === 'auto' ? (
            <div className="flex items-center gap-2 text-[11px] text-neutral-400 bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Adaptive Bitrate dynamically adjusts (3000 - 6500 Kbps) based on real-time Android NetworkCapabilities.
              </span>
            </div>
          ) : (
            <div>
              <div className="flex justify-between text-xs font-mono font-bold text-neutral-300 mb-1">
                <span>Target Bitrate:</span>
                <span className="text-rose-400">{settings.manualBitrateKbps} Kbps</span>
              </div>
              <input
                type="range"
                min={2000}
                max={9000}
                step={250}
                value={settings.manualBitrateKbps}
                onChange={(e) =>
                  onUpdateSettings({ manualBitrateKbps: Number(e.target.value) })
                }
                className="w-full accent-rose-500 cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-neutral-500 font-mono mt-1">
                <span>2000 (Low)</span>
                <span>5500 (Recommended)</span>
                <span>9000 (Ultra)</span>
              </div>
            </div>
          )}
        </div>

        {/* Audio & Camera Toggles */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-neutral-200">
            Audio & Input Sources
          </label>

          {/* Microphone */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-xl ${
                  settings.microphoneEnabled
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-neutral-800 text-neutral-500'
                }`}
              >
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-neutral-200">Microphone Audio</p>
                <p className="text-[10px] text-neutral-400">Streamer voice commentary</p>
              </div>
            </div>
            <button
              onClick={() =>
                onUpdateSettings({ microphoneEnabled: !settings.microphoneEnabled })
              }
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.microphoneEnabled ? 'bg-emerald-500' : 'bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform ${
                  settings.microphoneEnabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Game Internal Audio */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-xl ${
                  settings.gameAudioEnabled
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
                    : 'bg-neutral-800 text-neutral-500'
                }`}
              >
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-neutral-200">Internal Game Audio</p>
                <p className="text-[10px] text-neutral-400">AudioPlaybackCapture (Android 10+)</p>
              </div>
            </div>
            <button
              onClick={() =>
                onUpdateSettings({ gameAudioEnabled: !settings.gameAudioEnabled })
              }
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.gameAudioEnabled ? 'bg-cyan-500' : 'bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform ${
                  settings.gameAudioEnabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Camera PIP */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-xl ${
                  settings.cameraEnabled
                    ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                    : 'bg-neutral-800 text-neutral-500'
                }`}
              >
                <Camera className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-neutral-200">Facecam (PIP)</p>
                <p className="text-[10px] text-neutral-400">Picture-in-picture front camera</p>
              </div>
            </div>
            <button
              onClick={() =>
                onUpdateSettings({ cameraEnabled: !settings.cameraEnabled })
              }
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.cameraEnabled ? 'bg-rose-500' : 'bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform ${
                  settings.cameraEnabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Hardware Encoder Info */}
        <div className="p-3 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-rose-400" />
            <div>
              <p className="font-bold text-neutral-200">Hardware H.264 (AVC)</p>
              <p className="text-[10px] text-neutral-400">Low CPU latency • Zero frame stutters</p>
            </div>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-bold">
            ENABLED
          </span>
        </div>
      </div>

      {/* Bottom Button */}
      <div className="p-4 border-t border-neutral-900 bg-neutral-950/95 sticky bottom-0">
        <button
          onClick={onNext}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-bold text-xs shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <span>CONTINUE TO LIVE PREVIEW</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
