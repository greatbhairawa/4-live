import React, { useState } from 'react';
import { HeaderBar } from '../common/HeaderBar';
import { ChatMessage } from '../../types/stream';
import {
  MessageSquare,
  Send,
  Shield,
  Volume2,
  Sparkles,
  Smile,
  Heart,
  Flame,
  ThumbsUp,
} from 'lucide-react';

interface ChatScreenProps {
  onBack?: () => void;
  isLive?: boolean;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({ onBack, isLive = false }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'c1',
      sender: 'HyperWolf_99',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=60&auto=format&fit=crop&q=80',
      message: 'That headshot was insane!! GG!',
      timestamp: '11:02',
      isSub: true,
      color: '#06B6D4',
    },
    {
      id: 'c2',
      sender: 'NovaMod_Official',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&auto=format&fit=crop&q=80',
      message: 'Stream rules: Be respectful, no self-promo, have fun in the squad!',
      timestamp: '11:03',
      isMod: true,
      color: '#F43F5E',
    },
    {
      id: 'c3',
      sender: 'GamerSamurai',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=60&auto=format&fit=crop&q=80',
      message: 'Sent $5.00 SuperChat: "Keep grinding bro, best mobile streamer!"',
      timestamp: '11:04',
      superChatAmount: 5.0,
      color: '#F59E0B',
    },
    {
      id: 'c4',
      sender: 'SkyRider',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=60&auto=format&fit=crop&q=80',
      message: 'Which weapon attachment are you using for recoil?',
      timestamp: '11:04',
      color: '#10B981',
    },
  ]);

  const [inputVal, setInputVal] = useState('');
  const [ttsEnabled, setTtsEnabled] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    setMessages((prev) => [
      ...prev,
      {
        id: `c-${Date.now()}`,
        sender: 'NeonStriker_4L (Streamer)',
        avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=60&auto=format&fit=crop&q=80',
        message: inputVal.trim(),
        timestamp: 'Just now',
        isMod: true,
        color: '#F43F5E',
      },
    ]);
    setInputVal('');
  };

  const addQuickReaction = (emoji: string) => {
    setInputVal((prev) => prev + ' ' + emoji);
  };

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-hidden">
      <HeaderBar
        title="Live Stream Chat"
        subtitle="Aggregated multi-platform feed"
        onBack={onBack}
        rightAction={
          <button
            onClick={() => setTtsEnabled(!ttsEnabled)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
              ttsEnabled
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                : 'bg-neutral-900 text-neutral-400 border-neutral-800'
            }`}
            title="Text To Speech for Streamer Headphones"
          >
            <Volume2 className="w-3 h-3" />
            <span>TTS {ttsEnabled ? 'ON' : 'OFF'}</span>
          </button>
        }
      />

      {/* Messages Feed */}
      <div className="flex-1 p-3 overflow-y-auto flex flex-col gap-2.5">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`p-2.5 rounded-2xl border transition-all ${
              m.superChatAmount
                ? 'bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-transparent border-amber-500/40 shadow-lg'
                : 'bg-neutral-900/70 border-neutral-800/80'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <img
                  src={m.avatar}
                  alt={m.sender}
                  className="w-5 h-5 rounded-full object-cover border border-neutral-700"
                />
                <div className="flex items-center gap-1.5">
                  {m.isMod && (
                    <span className="text-[8px] font-bold bg-rose-500/20 text-rose-400 px-1 py-0.2 rounded border border-rose-500/30">
                      MOD
                    </span>
                  )}
                  {m.isSub && (
                    <span className="text-[8px] font-bold bg-cyan-500/20 text-cyan-400 px-1 py-0.2 rounded border border-cyan-500/30">
                      SUB
                    </span>
                  )}
                  {m.superChatAmount && (
                    <span className="text-[8px] font-bold bg-amber-500/20 text-amber-300 px-1 py-0.2 rounded border border-amber-500/30">
                      ★ SUPERCHAT ${m.superChatAmount.toFixed(2)}
                    </span>
                  )}
                  <span
                    className="text-xs font-bold leading-none"
                    style={{ color: m.color || '#fff' }}
                  >
                    {m.sender}
                  </span>
                </div>
              </div>
              <span className="text-[9px] text-neutral-500 font-mono">{m.timestamp}</span>
            </div>

            <p className="text-xs text-neutral-200 pl-7 leading-relaxed">{m.message}</p>
          </div>
        ))}
      </div>

      {/* Quick Reaction Bar */}
      <div className="px-3 py-1.5 bg-neutral-900/80 border-t border-neutral-800/80 flex items-center gap-2">
        {['🔥', '❤️', '👏', 'GG', '100%'].map((emoji) => (
          <button
            key={emoji}
            onClick={() => addQuickReaction(emoji)}
            className="px-2 py-0.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-neutral-200 cursor-pointer"
          >
            {emoji}
          </button>
        ))}
      </div>

      {/* Chat Input */}
      <form
        onSubmit={handleSend}
        className="p-3 bg-neutral-950 border-t border-neutral-900 flex items-center gap-2"
      >
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Reply as NeonStriker_4L..."
          className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
        />
        <button
          type="submit"
          className="p-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white cursor-pointer active:scale-95 transition-all shadow-md shadow-rose-600/30"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
