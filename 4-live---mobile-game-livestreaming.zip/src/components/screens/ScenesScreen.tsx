import React from 'react';
import { SceneItem } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Layers,
  Check,
  Video,
  MessageSquare,
  Bell,
  Play,
  Sparkles,
} from 'lucide-react';

interface ScenesScreenProps {
  onBack?: () => void;
  scenes: SceneItem[];
  activeSceneId: string;
  onSelectScene: (id: string) => void;
  isLive?: boolean;
}

export const ScenesScreen: React.FC<ScenesScreenProps> = ({
  onBack,
  scenes,
  activeSceneId,
  onSelectScene,
  isLive = false,
}) => {
  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Scenes & Layouts"
        subtitle={isLive ? 'Active Broadcaster Switcher' : 'Pre-configure Stream Scenes'}
        onBack={onBack}
        rightAction={
          isLive ? (
            <span className="flex items-center gap-1 text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20 font-bold">
              HOT-SWAP
            </span>
          ) : undefined
        }
      />

      <div className="p-4 flex-1 flex flex-col gap-3">
        <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-purple-400" />
            <div>
              <p className="text-xs font-bold text-neutral-200">1-Tap Scene Transitions</p>
              <p className="text-[10px] text-neutral-400">
                Smooth fade transition without dropping RTMP frames
              </p>
            </div>
          </div>
        </div>

        {/* Scene Cards List */}
        <div className="flex flex-col gap-2.5">
          {scenes.map((scene) => {
            const isActive = activeSceneId === scene.id;
            return (
              <div
                key={scene.id}
                onClick={() => onSelectScene(scene.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col gap-2.5 ${
                  isActive
                    ? 'bg-neutral-900 border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.15)]'
                    : 'bg-neutral-900/60 border-neutral-800 hover:bg-neutral-850 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-xl border flex items-center justify-center font-bold text-xs ${
                        isActive
                          ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                          : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                      }`}
                    >
                      <Layers className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-neutral-100">{scene.name}</h4>
                      <p className="text-[10px] text-neutral-400">{scene.tagline}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isActive ? (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20">
                        <Check className="w-3 h-3 stroke-[3]" />
                        <span>ACTIVE</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        className="text-[10px] text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800"
                      >
                        Switch
                      </button>
                    )}
                  </div>
                </div>

                {/* Scene Feature Chips */}
                <div className="flex items-center gap-2 pt-2 border-t border-neutral-800/80 text-[10px] text-neutral-400">
                  <span
                    className={`flex items-center gap-1 ${
                      scene.showCamera ? 'text-emerald-400' : 'text-neutral-500 line-through'
                    }`}
                  >
                    <Video className="w-3 h-3" />
                    <span>Facecam</span>
                  </span>
                  <span>•</span>
                  <span
                    className={`flex items-center gap-1 ${
                      scene.showChat ? 'text-cyan-400' : 'text-neutral-500 line-through'
                    }`}
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>Live Chat</span>
                  </span>
                  <span>•</span>
                  <span
                    className={`flex items-center gap-1 ${
                      scene.showAlerts ? 'text-amber-400' : 'text-neutral-500 line-through'
                    }`}
                  >
                    <Bell className="w-3 h-3" />
                    <span>Sub Alerts</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
