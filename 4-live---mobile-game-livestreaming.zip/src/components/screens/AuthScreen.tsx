import React, { useState } from 'react';
import { Lock, Mail, User, ShieldCheck, ArrowRight, Gamepad2, Radio } from 'lucide-react';

interface AuthScreenProps {
  onSuccess: (streamerName: string) => void;
  onSkipGuest: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onSuccess, onSkipGuest }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [handle, setHandle] = useState('NeonStriker_4L');
  const [email, setEmail] = useState('striker@4live.gaming');
  const [password, setPassword] = useState('••••••••••••');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSuccess(handle || 'Gamer_4L');
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-neutral-950 text-white overflow-y-auto">
      {/* Brand Header */}
      <div className="pt-2">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center font-black text-white text-base">
            4L
          </div>
          <span className="font-extrabold text-base tracking-tight text-white">4 LIVE</span>
          <span className="ml-auto text-[10px] font-mono text-neutral-400 bg-neutral-900 border border-neutral-800 px-2 py-0.5 rounded-full">
            AES-256 Auth
          </span>
        </div>
        <h2 className="text-xl font-extrabold text-white tracking-tight">
          {isSignUp ? 'Create Creator Account' : 'Streamer Sign In'}
        </h2>
        <p className="text-xs text-neutral-400 mt-0.5">
          {isSignUp
            ? 'Broadcast directly to YouTube, Twitch, Kick & Custom RTMP'
            : 'Welcome back! Your broadcast keys are protected in Keystore'}
        </p>
      </div>

      {/* Auth Form */}
      <form onSubmit={handleSubmit} className="flex flex-col gap-3 my-4">
        {isSignUp && (
          <div>
            <label className="text-[11px] font-semibold text-neutral-300 mb-1 block">
              Creator GamerTag
            </label>
            <div className="relative flex items-center">
              <User className="absolute left-3 w-4 h-4 text-neutral-500" />
              <input
                type="text"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                placeholder="e.g. NeonStriker"
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
                required
              />
            </div>
          </div>
        )}

        <div>
          <label className="text-[11px] font-semibold text-neutral-300 mb-1 block">
            Email / Streamer ID
          </label>
          <div className="relative flex items-center">
            <Mail className="absolute left-3 w-4 h-4 text-neutral-500" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="streamer@game.live"
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
              required
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-semibold text-neutral-300">
              Master Password
            </label>
            {!isSignUp && (
              <button type="button" className="text-[10px] text-rose-400 hover:underline">
                Forgot?
              </button>
            )}
          </div>
          <div className="relative flex items-center">
            <Lock className="absolute left-3 w-4 h-4 text-neutral-500" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
              required
            />
          </div>
        </div>

        {/* Security badge */}
        <div className="flex items-center gap-2 p-2.5 rounded-xl bg-neutral-900/60 border border-neutral-800/80 text-[10px] text-neutral-400 mt-1">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Stream keys are stored securely using Android EncryptedSharedPreferences.</span>
        </div>

        <button
          type="submit"
          className="w-full mt-2 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
        >
          <span>{isSignUp ? 'Create 4 LIVE Account' : 'Sign In & Connect Platforms'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </form>

      {/* Divider */}
      <div className="relative flex items-center justify-center my-1">
        <div className="border-t border-neutral-800 w-full" />
        <span className="bg-neutral-950 px-2 text-[10px] text-neutral-500 uppercase tracking-wider font-semibold">
          OR
        </span>
      </div>

      {/* Alternative actions */}
      <div className="flex flex-col gap-2 pt-1 pb-2">
        <button
          onClick={onSkipGuest}
          className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors"
        >
          <Gamepad2 className="w-4 h-4 text-cyan-400" />
          <span>Instant Guest Streamer Mode</span>
        </button>

        <div className="text-center mt-2">
          <button
            type="button"
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-xs text-neutral-400 hover:text-white"
          >
            {isSignUp ? 'Already have an account? ' : "Don't have a 4 LIVE account? "}
            <span className="text-rose-400 font-bold underline">
              {isSignUp ? 'Sign In' : 'Sign Up Free'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
