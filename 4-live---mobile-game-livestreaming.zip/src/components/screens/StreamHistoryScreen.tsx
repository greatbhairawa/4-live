import React, { useState } from 'react';
import { PastStream } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Clock,
  Eye,
  Play,
  Share2,
  Calendar,
  Sparkles,
  TrendingUp,
  X,
} from 'lucide-react';

interface StreamHistoryScreenProps {
  onBack?: () => void;
  history: PastStream[];
}

export const StreamHistoryScreen: React.FC<StreamHistoryScreenProps> = ({
  onBack,
  history,
}) => {
  const [selectedStream, setSelectedStream] = useState<PastStream | null>(null);

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Stream History & VODs"
        subtitle="Past broadcasts, analytics & clips"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-3">
        {history.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedStream(item)}
            className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 hover:border-neutral-700 cursor-pointer transition-all flex flex-col gap-2.5"
          >
            <div className="flex items-start gap-3">
              <div className="relative w-20 h-14 rounded-xl overflow-hidden bg-neutral-800 shrink-0">
                <img
                  src={item.thumbnailUrl}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <div className="w-6 h-6 rounded-full bg-rose-600/80 flex items-center justify-center">
                    <Play className="w-3 h-3 fill-white text-white ml-0.5" />
                  </div>
                </div>
                <span className="absolute bottom-1 right-1 bg-black/80 px-1 py-0.2 rounded text-[8px] font-mono text-neutral-300">
                  {item.duration}
                </span>
              </div>

              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-neutral-100 truncate">{item.title}</h4>
                <p className="text-[10px] text-rose-400 font-semibold mt-0.5">{item.game}</p>
                <div className="flex items-center gap-2 text-[9px] text-neutral-400 mt-1">
                  <span>{item.date}</span>
                  <span>•</span>
                  <span className="flex items-center gap-0.5">
                    <Eye className="w-3 h-3" />
                    {item.totalViews} views
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  {item.performanceScore}% Score
                </span>
              </div>
            </div>

            {/* Platforms row */}
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800/80 text-[10px] text-neutral-400">
              <div className="flex items-center gap-1.5 font-mono text-[9px]">
                <span>Platforms:</span>
                {item.platforms.map((p) => (
                  <span
                    key={p}
                    className="px-1.5 py-0.2 rounded bg-neutral-800 uppercase font-bold text-neutral-300"
                  >
                    {p}
                  </span>
                ))}
              </div>

              <span className="text-neutral-400 font-mono text-[9px]">
                Peak CCU: <strong className="text-neutral-200">{item.peakCcu}</strong>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* VOD Detail Modal */}
      {selectedStream && (
        <div className="absolute inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-rose-400 font-bold bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/20">
                Broadcast Summary
              </span>
              <button
                onClick={() => setSelectedStream(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <h3 className="text-sm font-extrabold text-white">{selectedStream.title}</h3>
            <p className="text-xs text-neutral-400">{selectedStream.game} • {selectedStream.date}</p>

            <div className="grid grid-cols-2 gap-2 my-1">
              <div className="p-2.5 bg-neutral-950 rounded-xl border border-neutral-800 text-center">
                <span className="text-[9px] text-neutral-400 uppercase">Total Views</span>
                <p className="text-sm font-black text-white mt-0.5">{selectedStream.totalViews}</p>
              </div>
              <div className="p-2.5 bg-neutral-950 rounded-xl border border-neutral-800 text-center">
                <span className="text-[9px] text-neutral-400 uppercase">Peak CCU</span>
                <p className="text-sm font-black text-rose-400 mt-0.5">{selectedStream.peakCcu}</p>
              </div>
            </div>

            <div className="flex gap-2 mt-2">
              <button
                onClick={() => setSelectedStream(null)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-bold"
              >
                Close
              </button>
              <button
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  alert('VOD link copied to clipboard!');
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center justify-center gap-1.5"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share Clip</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
