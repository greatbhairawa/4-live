import React, { useState } from 'react';
import { GameItem } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import { Gamepad2, Sparkles, Globe, Lock, Eye, Tag, ArrowRight } from 'lucide-react';

interface StartLiveScreenProps {
  onBack: () => void;
  onNext: () => void;
  title: string;
  setTitle: (title: string) => void;
  description: string;
  setDescription: (desc: string) => void;
  privacy: 'public' | 'unlisted' | 'private';
  setPrivacy: (p: 'public' | 'unlisted' | 'private') => void;
  tags: string[];
  setTags: (tags: string[]) => void;
  selectedGame: GameItem;
  setSelectedGame: (game: GameItem) => void;
  games: GameItem[];
}

export const StartLiveScreen: React.FC<StartLiveScreenProps> = ({
  onBack,
  onNext,
  title,
  setTitle,
  description,
  setDescription,
  privacy,
  setPrivacy,
  tags,
  setTags,
  selectedGame,
  setSelectedGame,
  games,
}) => {
  const [tagInput, setTagInput] = useState('');

  const titleSuggestions = [
    `🔥 Solo vs Squads in ${selectedGame.name} - Road to #1`,
    `Ranked Push with Viewers! Drop your gamer ID below`,
    `🔴 LIVE: Pro Tournament Practice & Highlights`,
    `Weekend Gaming Grind! Chill vibes & High Kills`,
  ];

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim().replace(/^#/, '')]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Start Live Broadcast"
        subtitle="Step 1 of 4: Stream Info"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-4">
        {/* Stream Title Section */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-neutral-200">
              Broadcast Title <span className="text-rose-500">*</span>
            </label>
            <button
              onClick={() => {
                const random = titleSuggestions[Math.floor(Math.random() * titleSuggestions.length)];
                setTitle(random);
              }}
              className="text-[10px] text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-3 h-3" />
              <span>Generate Title</span>
            </button>
          </div>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Solo vs Squads - Conqueror Rank Push"
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors font-medium"
            maxLength={100}
          />
          <div className="flex justify-between items-center mt-1 text-[10px] text-neutral-500">
            <span>Make it catchy to attract mobile viewers</span>
            <span>{title.length}/100</span>
          </div>
        </div>

        {/* Selected Game / Category */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-neutral-200">
              Select Game / Category <span className="text-rose-500">*</span>
            </label>
            <span className="text-[10px] text-neutral-400 font-medium">
              {games.length} games supported
            </span>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {games.map((game) => {
              const isSelected = selectedGame.id === game.id;
              return (
                <button
                  key={game.id}
                  onClick={() => setSelectedGame(game)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl shrink-0 border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-rose-500/15 border-rose-500 text-white font-bold'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <img
                    src={game.iconUrl}
                    alt={game.name}
                    className="w-5 h-5 rounded-md object-cover"
                  />
                  <span className="text-xs truncate max-w-[120px]">{game.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Privacy Setting */}
        <div>
          <label className="text-xs font-bold text-neutral-200 mb-1.5 block">
            Stream Privacy
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'public' as const, label: 'Public', icon: Globe, desc: 'Anyone can watch' },
              { id: 'unlisted' as const, label: 'Unlisted', icon: Eye, desc: 'Link only' },
              { id: 'private' as const, label: 'Private', icon: Lock, desc: 'Test stream only' },
            ].map((option) => {
              const Icon = option.icon;
              const isSelected = privacy === option.id;
              return (
                <button
                  key={option.id}
                  onClick={() => setPrivacy(option.id)}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-rose-500/10 border-rose-500 text-rose-400'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Icon className="w-4 h-4 mb-1" />
                  <span className="text-xs font-bold">{option.label}</span>
                  <span className="text-[9px] text-neutral-500 mt-0.5">{option.desc}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tags */}
        <div>
          <label className="text-xs font-bold text-neutral-200 mb-1.5 block">
            Tags & Hashtags
          </label>
          <div className="flex gap-2 mb-2">
            <div className="relative flex-1">
              <Tag className="absolute left-3 top-2.5 w-3.5 h-3.5 text-neutral-500" />
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                placeholder="Add tag (e.g. mobileesports, solo)"
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
              />
            </div>
            <button
              type="button"
              onClick={handleAddTag}
              className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold cursor-pointer"
            >
              Add
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {tags.map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 font-medium"
              >
                #{tag}
                <button
                  type="button"
                  onClick={() => handleRemoveTag(tag)}
                  className="text-neutral-500 hover:text-rose-400 ml-1 font-bold"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="text-xs font-bold text-neutral-200 mb-1.5 block">
            Stream Description (Optional)
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Tell your viewers what you're doing in this broadcast..."
            rows={2}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 resize-none"
          />
        </div>
      </div>

      {/* Bottom Action */}
      <div className="p-4 border-t border-neutral-900 bg-neutral-950/95 sticky bottom-0">
        <button
          onClick={onNext}
          disabled={!title.trim()}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <span>SELECT PLATFORMS</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
