import React, { useState, useRef, useEffect } from 'react';
import { StreamSessionState, OverlayConfig } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Radio,
  Camera,
  Mic,
  Volume2,
  Monitor,
  ShieldAlert,
  Play,
  CheckCircle2,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface LivePreviewScreenProps {
  onBack: () => void;
  onStartLive: () => void;
  session: StreamSessionState;
  overlay: OverlayConfig;
  onEditSettings: () => void;
}

export const LivePreviewScreen: React.FC<LivePreviewScreenProps> = ({
  onBack,
  onStartLive,
  session,
  overlay,
  onEditSettings,
}) => {
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [useRealScreen, setUseRealScreen] = useState(false);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [webcamStream, setWebcamStream] = useState<MediaStream | null>(null);
  const [vuLevel, setVuLevel] = useState(45);

  const videoRef = useRef<HTMLVideoElement>(null);
  const camVideoRef = useRef<HTMLVideoElement>(null);

  // Simulated audio meter fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setVuLevel(Math.floor(Math.random() * 50) + 30);
    }, 120);
    return () => clearInterval(interval);
  }, []);

  // Real screen capture test toggle
  const handleToggleRealScreen = async () => {
    if (useRealScreen) {
      screenStream?.getTracks().forEach((t) => t.stop());
      setScreenStream(null);
      setUseRealScreen(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        });
        setScreenStream(stream);
        setUseRealScreen(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.warn('Screen share cancelled or not supported:', err);
      }
    }
  };

  // Real webcam test toggle
  const handleToggleWebcam = async () => {
    if (webcamStream) {
      webcamStream.getTracks().forEach((t) => t.stop());
      setWebcamStream(null);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
        setWebcamStream(stream);
        if (camVideoRef.current) {
          camVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.warn('Webcam permission not granted:', err);
      }
    }
  };

  useEffect(() => {
    return () => {
      screenStream?.getTracks().forEach((t) => t.stop());
      webcamStream?.getTracks().forEach((t) => t.stop());
    };
  }, [screenStream, webcamStream]);

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Live Broadcast Preview"
        subtitle="Step 4 of 4: Verify Feed & Start"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-3.5">
        {/* Live Canvas / Video Stage Preview */}
        <div className="relative w-full aspect-video bg-neutral-900 rounded-2xl overflow-hidden border-2 border-rose-500/50 shadow-2xl flex flex-col justify-between">
          
          {/* Main Gameplay Canvas / Video */}
          <div className="absolute inset-0 z-0">
            {useRealScreen && screenStream ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="relative w-full h-full">
                <img
                  src={session.selectedGame.bannerUrl}
                  alt={session.selectedGame.name}
                  className="w-full h-full object-cover filter brightness-90 contrast-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
                
                {/* Simulated Game Action Tag */}
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-sm border border-neutral-700 text-[9px] font-mono text-cyan-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                  <span>SIMULATED SCREEN FEED</span>
                </div>
              </div>
            )}
          </div>

          {/* Active Overlay: Cyber Crimson Frame */}
          {overlay.borderStyle !== 'none' && (
            <div className="absolute inset-0 pointer-events-none z-10 border-4 border-rose-500/80 rounded-2xl shadow-[inset_0_0_20px_rgba(244,63,94,0.4)]">
              {/* Corner accents */}
              <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
              <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
              <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
              <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />
            </div>
          )}

          {/* Overlay: Follower / Donation Goal */}
          {overlay.showGoalBar && (
            <div className="relative z-20 mx-3 mt-2 px-2.5 py-1 rounded-lg bg-black/75 backdrop-blur-md border border-neutral-700 flex items-center justify-between text-[9px]">
              <div className="flex items-center gap-1.5 truncate max-w-[65%]">
                <span className="text-rose-400 font-bold uppercase">{overlay.goalTitle}</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono">
                <div className="w-16 h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-rose-500 to-amber-400 rounded-full"
                    style={{ width: `${(overlay.goalCurrent / overlay.goalTarget) * 100}%` }}
                  />
                </div>
                <span className="text-neutral-300 font-semibold">
                  {overlay.goalCurrent}/{overlay.goalTarget}
                </span>
              </div>
            </div>
          )}

          {/* Facecam Picture-In-Picture */}
          {session.settings.cameraEnabled && (
            <div
              className={`absolute z-20 w-16 h-16 rounded-xl overflow-hidden border-2 border-rose-500 bg-neutral-900 shadow-lg ${
                overlay.camPosition === 'top_left'
                  ? 'top-8 left-3'
                  : overlay.camPosition === 'bottom_left'
                  ? 'bottom-8 left-3'
                  : overlay.camPosition === 'bottom_right'
                  ? 'bottom-8 right-3'
                  : 'top-8 right-3'
              }`}
            >
              {webcamStream ? (
                <video
                  ref={camVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover transform -scale-x-100"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-neutral-800 to-neutral-900 text-center p-1">
                  <Camera className="w-4 h-4 text-rose-400 mb-0.5" />
                  <span className="text-[8px] font-bold text-neutral-300">FACECAM</span>
                  <span className="text-[7px] text-emerald-400 font-mono">ON AIR</span>
                </div>
              )}
            </div>
          )}

          {/* Social Handle Banner at bottom */}
          {overlay.showSocials && (
            <div className="relative z-20 mx-3 mb-2 flex items-center justify-between text-[9px] bg-black/75 backdrop-blur-md px-2 py-0.5 rounded border border-neutral-800">
              <span className="text-neutral-300 font-semibold truncate">
                🎮 {session.selectedGame.name}
              </span>
              <span className="text-rose-400 font-mono font-bold">{overlay.socialHandle}</span>
            </div>
          )}
        </div>

        {/* Screen feed source switcher */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={handleToggleRealScreen}
            className={`flex-1 py-2 px-2.5 rounded-xl border text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              useRealScreen
                ? 'bg-rose-500/15 border-rose-500 text-rose-300'
                : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-850'
            }`}
          >
            <Monitor className="w-3.5 h-3.5 text-rose-400" />
            <span>{useRealScreen ? 'Sharing Real Screen' : 'Capture My Real Screen'}</span>
          </button>

          {session.settings.cameraEnabled && (
            <button
              type="button"
              onClick={handleToggleWebcam}
              className={`py-2 px-3 rounded-xl border text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                webcamStream
                  ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-850'
              }`}
            >
              <Camera className="w-3.5 h-3.5 text-cyan-400" />
              <span>{webcamStream ? 'Webcam Live' : 'Test Webcam'}</span>
            </button>
          )}
        </div>

        {/* Audio VU Monitor */}
        <div className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-bold text-neutral-200 flex items-center gap-1.5">
              <Mic className="w-3.5 h-3.5 text-cyan-400" />
              <span>Audio Input Monitor</span>
            </span>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">
              {session.settings.microphoneEnabled ? 'STEREO 48kHz' : 'MUTED'}
            </span>
          </div>

          {/* VU Meter Bars */}
          <div className="flex items-center gap-1 h-3 bg-neutral-950 p-0.5 rounded-lg border border-neutral-800">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-yellow-400 to-rose-500 rounded transition-all duration-100"
              style={{ width: `${session.settings.microphoneEnabled ? vuLevel : 0}%` }}
            />
          </div>
          <div className="flex justify-between text-[9px] text-neutral-500 font-mono mt-1">
            <span>-40 dB</span>
            <span>-12 dB (Normal)</span>
            <span>0 dB (Peak)</span>
          </div>
        </div>

        {/* Pre-flight Stream Verification Checklist */}
        <div className="p-3 rounded-2xl bg-neutral-900/50 border border-neutral-800 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs font-bold text-neutral-300">
            <span>Stream Health Diagnostics</span>
            <button
              onClick={onEditSettings}
              className="text-[10px] text-rose-400 hover:underline cursor-pointer"
            >
              Edit Specs
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div className="flex items-center gap-1.5 text-neutral-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                Quality: <strong>{session.settings.resolution} {session.settings.fps}fps</strong>
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                Bitrate: <strong>{session.settings.manualBitrateKbps} Kbps</strong>
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                Dests: <strong>{session.selectedPlatforms.length} Platforms</strong>
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                Engine: <strong>Hardware H.264</strong>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Start Broadcast Button */}
      <div className="p-4 border-t border-neutral-900 bg-neutral-950/95 sticky bottom-0">
        <button
          onClick={() => setShowConsentModal(true)}
          className="w-full py-4 px-4 rounded-2xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-black text-sm tracking-wider uppercase shadow-[0_4px_25px_rgba(244,63,94,0.45)] active:scale-98 flex items-center justify-center gap-2.5 cursor-pointer transition-all border border-rose-400/30"
        >
          <Radio className="w-5 h-5 animate-pulse" />
          <span>START LIVE BROADCAST</span>
        </button>
      </div>

      {/* Android Native MediaProjection Permission Dialog */}
      {showConsentModal && (
        <div className="absolute inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl flex flex-col gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-white">Start Recording or Casting?</h3>
                <p className="text-[11px] text-neutral-400">Android MediaProjection Service</p>
              </div>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-950 p-3 rounded-2xl border border-neutral-800">
              <strong>4 LIVE</strong> will have access to all of the information that is visible on
              your screen or played from your device while recording or casting. This includes
              passwords, payment info, photos, and messages.
            </p>

            <div className="flex items-center gap-2 text-[10px] text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>4 LIVE Privacy Shield is active to mask sensitive inputs.</span>
            </div>

            <div className="flex gap-2.5 mt-2">
              <button
                type="button"
                onClick={() => setShowConsentModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowConsentModal(false);
                  onStartLive();
                }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-rose-600/30 cursor-pointer transition-all"
              >
                Start Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
