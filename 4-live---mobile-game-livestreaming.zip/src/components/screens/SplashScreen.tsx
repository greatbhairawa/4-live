import React, { useState, useEffect } from 'react';
import { Radio, ShieldCheck, Cpu, Mic, CheckCircle2 } from 'lucide-react';

interface SplashScreenProps {
  onContinue: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onContinue }) => {
  const [initProgress, setInitProgress] = useState(0);
  const [statusText, setStatusText] = useState('Initializing MediaProjection Engine...');

  useEffect(() => {
    const timer = setInterval(() => {
      setInitProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        const next = prev + 25;
        if (next === 25) setStatusText('Verifying Hardware H.264 Encoder...');
        if (next === 50) setStatusText('Checking AudioCapture & Mic pipeline...');
        if (next === 75) setStatusText('Loading AES-256 Encrypted Keystore...');
        if (next >= 100) setStatusText('4 LIVE Engine Ready');
        return next;
      });
    }, 450);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative flex-1 flex flex-col justify-between p-6 bg-gradient-to-b from-neutral-950 via-neutral-900 to-neutral-950 text-white overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-64 h-64 bg-rose-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-48 h-48 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Brand Tag */}
      <div className="flex items-center justify-between z-10 pt-2">
        <span className="text-[10px] font-mono tracking-widest text-neutral-400 uppercase bg-neutral-800/60 px-2.5 py-1 rounded-full border border-neutral-700/40">
          Android Native Engine v1.0
        </span>
        <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
          <span>STANDBY</span>
        </div>
      </div>

      {/* Center Branding */}
      <div className="flex flex-col items-center justify-center z-10 text-center my-auto">
        <div className="relative mb-5">
          {/* Logo Badge */}
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-rose-600 via-rose-500 to-amber-500 flex items-center justify-center shadow-[0_0_40px_rgba(244,63,94,0.4)] border border-rose-400/40">
            <div className="flex items-baseline font-black tracking-tighter text-white">
              <span className="text-4xl">4</span>
              <Radio className="w-7 h-7 -ml-0.5 text-white animate-pulse" />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-md bg-neutral-900 border border-neutral-700 text-[9px] font-bold tracking-wider text-rose-400 uppercase">
            LIVE
          </div>
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight text-white flex items-center gap-1.5">
          <span>4 LIVE</span>
        </h1>
        <p className="text-xs text-rose-400 font-medium tracking-wide mt-1">
          Play • Stream • Connect • Create
        </p>

        <p className="text-xs text-neutral-400 max-w-[260px] mt-4 leading-relaxed">
          High-performance mobile gaming screen broadcast engine with zero frame drops and studio-grade overlays.
        </p>
      </div>

      {/* Bottom Initialization & Actions */}
      <div className="flex flex-col gap-4 z-10 pb-4">
        {/* Progress Bar & Diagnostic checks */}
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-3.5 backdrop-blur-sm">
          <div className="flex items-center justify-between text-[11px] mb-2">
            <span className="text-neutral-400 flex items-center gap-1.5 truncate">
              {initProgress < 100 ? (
                <Cpu className="w-3.5 h-3.5 text-rose-400 animate-spin" />
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span className="truncate">{statusText}</span>
            </span>
            <span className="font-mono text-neutral-300 font-semibold">{initProgress}%</span>
          </div>
          <div className="h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-rose-500 to-cyan-400 transition-all duration-300 rounded-full"
              style={{ width: `${initProgress}%` }}
            />
          </div>

          <div className="grid grid-cols-3 gap-1.5 mt-3 pt-2.5 border-t border-neutral-800/80 text-[10px] text-neutral-400">
            <div className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>MediaProj</span>
            </div>
            <div className="flex items-center gap-1">
              <Mic className="w-3 h-3 text-cyan-400" />
              <span>Dual Audio</span>
            </div>
            <div className="flex items-center gap-1">
              <Radio className="w-3 h-3 text-rose-400" />
              <span>RTMP 1080p</span>
            </div>
          </div>
        </div>

        <button
          onClick={onContinue}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-bold text-sm shadow-[0_4px_20px_rgba(244,63,94,0.35)] active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <span>ENTER 4 LIVE STUDIO</span>
          <Radio className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
