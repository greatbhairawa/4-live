import React, { useState } from 'react';
import { PlatformConfig, PlatformId } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Check,
  Plus,
  ShieldCheck,
  Server,
  Radio,
  Eye,
  EyeOff,
  ArrowRight,
  Layers,
  HelpCircle,
} from 'lucide-react';

interface PlatformSelectionScreenProps {
  onBack: () => void;
  onNext: () => void;
  platforms: PlatformConfig[];
  selectedPlatforms: PlatformId[];
  onTogglePlatform: (id: PlatformId) => void;
  onUpdateCustomRtmp: (url: string, key: string) => void;
}

export const PlatformSelectionScreen: React.FC<PlatformSelectionScreenProps> = ({
  onBack,
  onNext,
  platforms,
  selectedPlatforms,
  onTogglePlatform,
  onUpdateCustomRtmp,
}) => {
  const [showRtmpModal, setShowRtmpModal] = useState(false);
  const [rtmpUrl, setRtmpUrl] = useState('rtmp://live.twitch.tv/app');
  const [rtmpKey, setRtmpKey] = useState('live_92019482_vX9qLmP81k39');
  const [showKey, setShowKey] = useState(false);

  const getPlatformIconColor = (id: PlatformId) => {
    switch (id) {
      case 'youtube':
        return 'text-red-500 bg-red-500/10 border-red-500/30';
      case 'twitch':
        return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
      case 'kick':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'facebook':
        return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
      case 'custom_rtmp':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
    }
  };

  const handleSaveRtmp = () => {
    onUpdateCustomRtmp(rtmpUrl, rtmpKey);
    setShowRtmpModal(false);
  };

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Streaming Platforms"
        subtitle="Step 2 of 4: Select Destinations"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-3.5">
        {/* Multistream Banner */}
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-200">Multistream Enabled</p>
              <p className="text-[10px] text-neutral-400">
                Broadcast to multiple platforms concurrently
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-bold">
            {selectedPlatforms.length} Active
          </span>
        </div>

        {/* Platform List */}
        <div className="flex flex-col gap-2">
          {platforms.map((platform) => {
            const isSelected = selectedPlatforms.includes(platform.id);
            const style = getPlatformIconColor(platform.id);

            return (
              <div
                key={platform.id}
                onClick={() => onTogglePlatform(platform.id)}
                className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-neutral-900 border-rose-500/80 shadow-[0_0_15px_rgba(244,63,94,0.15)]'
                    : 'bg-neutral-900/60 border-neutral-800 hover:bg-neutral-850 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl border flex items-center justify-center font-bold text-xs ${style}`}
                  >
                    {platform.id === 'youtube' && 'YT'}
                    {platform.id === 'twitch' && 'TW'}
                    {platform.id === 'kick' && 'KC'}
                    {platform.id === 'facebook' && 'FB'}
                    {platform.id === 'custom_rtmp' && <Server className="w-4 h-4" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-bold text-neutral-100">{platform.name}</p>
                      {platform.connected && (
                        <span className="text-[9px] text-emerald-400 font-semibold bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
                          Connected
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-neutral-400 mt-0.5">
                      {platform.username
                        ? `@${platform.username}`
                        : platform.id === 'custom_rtmp'
                        ? 'Custom RTMP Server & Key'
                        : 'Tap to connect'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {platform.id === 'custom_rtmp' && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowRtmpModal(true);
                      }}
                      className="px-2 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[10px] text-neutral-300 font-semibold border border-neutral-700"
                    >
                      Config
                    </button>
                  )}

                  <div
                    className={`w-5 h-5 rounded-lg flex items-center justify-center border transition-all ${
                      isSelected
                        ? 'bg-rose-500 border-rose-500 text-white'
                        : 'border-neutral-700 bg-neutral-800/50'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Security & KeyStore Guarantee */}
        <div className="p-3 rounded-2xl bg-neutral-900/40 border border-neutral-800 text-[10px] text-neutral-400 flex items-start gap-2.5 mt-auto">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="text-neutral-200 font-semibold">Zero-Trust Credential Security: </span>
            All broadcast tokens and stream keys are encrypted via Android Keystore MasterKey. Keys are never transmitted in cleartext.
          </div>
        </div>
      </div>

      {/* Bottom Button */}
      <div className="p-4 border-t border-neutral-900 bg-neutral-950/95 sticky bottom-0">
        <button
          onClick={onNext}
          disabled={selectedPlatforms.length === 0}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <span>CONFIGURE STREAM SETTINGS</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Custom RTMP Dialog Modal */}
      {showRtmpModal && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-rose-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Custom RTMP Settings
                </h3>
              </div>
              <button
                onClick={() => setShowRtmpModal(false)}
                className="text-neutral-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-col gap-3 my-2">
              <div>
                <label className="text-[11px] font-semibold text-neutral-300 mb-1 block">
                  RTMP Ingest Server URL
                </label>
                <input
                  type="text"
                  value={rtmpUrl}
                  onChange={(e) => setRtmpUrl(e.target.value)}
                  placeholder="rtmp://ingest.service.com/app"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500 font-mono"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-neutral-300 mb-1 block">
                  Private Stream Key
                </label>
                <div className="relative flex items-center">
                  <input
                    type={showKey ? 'text' : 'password'}
                    value={rtmpKey}
                    onChange={(e) => setRtmpKey(e.target.value)}
                    placeholder="live_sec_..."
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-3 pr-10 py-2 text-xs text-white focus:outline-none focus:border-rose-500 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 text-neutral-400 hover:text-neutral-200"
                  >
                    {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex gap-2 mt-4">
              <button
                onClick={() => setShowRtmpModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveRtmp}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Save & Select
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
