import React from 'react';
import {
  Radio,
  Settings as SettingsIcon,
  Play,
  Flame,
  Clock,
  ChevronRight,
  TrendingUp,
  Eye,
  Sliders,
  Layers,
  Sparkles,
} from 'lucide-react';
import { GameItem, PastStream, ScreenId } from '../../types/stream';

interface HomeScreenProps {
  onGoLive: () => void;
  onNavigate: (screen: ScreenId) => void;
  games: GameItem[];
  recentStreams: PastStream[];
  onSelectGame: (game: GameItem) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onGoLive,
  onNavigate,
  games,
  recentStreams,
  onSelectGame,
}) => {
  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto pb-4">
      {/* Top App Bar */}
      <div className="px-4 pt-3 pb-2 flex items-center justify-between border-b border-neutral-900 bg-neutral-950/95 sticky top-0 z-20 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-600 via-rose-500 to-amber-500 flex items-center justify-center shadow-[0_0_15px_rgba(244,63,94,0.4)]">
            <span className="font-black text-sm text-white tracking-tighter">4L</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm tracking-tight text-white">4 LIVE</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <p className="text-[10px] text-neutral-400 font-medium">Ready to broadcast</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onNavigate('stream_settings')}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800/80 transition-colors"
            title="Stream Settings"
          >
            <Sliders className="w-4 h-4 text-cyan-400" />
          </button>
          <button
            onClick={() => onNavigate('settings')}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800/80 transition-colors"
            title="App Settings"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Hero: Large GO LIVE Card */}
      <div className="p-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-neutral-900 via-neutral-900/90 to-neutral-950 border border-neutral-800/80 p-5 shadow-2xl">
          {/* Ambient glow */}
          <div className="absolute -top-12 -right-12 w-44 h-44 bg-rose-600/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-8 -left-8 w-36 h-36 bg-amber-600/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/25 text-rose-400 text-[10px] font-bold tracking-wide uppercase mb-3">
              <Sparkles className="w-3 h-3" />
              <span>Mobile Screen Cast Engine</span>
            </div>

            <h2 className="text-xl font-extrabold tracking-tight text-white mb-1">
              Broadcast Your Game
            </h2>
            <p className="text-xs text-neutral-400 max-w-[240px] mb-5">
              Stream screen in 1080p 60fps with internal game audio, mic, and facecam.
            </p>

            {/* Giant Pulsing GO LIVE Button */}
            <div className="relative group my-1">
              <div className="absolute -inset-1.5 bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500 rounded-3xl blur-md opacity-75 group-hover:opacity-100 animate-pulse transition duration-300" />
              <button
                onClick={onGoLive}
                className="relative px-8 py-4 rounded-2xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 active:scale-95 text-white font-black text-base tracking-wider uppercase shadow-xl flex items-center gap-3 transition-all cursor-pointer border border-rose-400/30"
              >
                <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                  <Radio className="w-4 h-4 text-white animate-pulse" />
                </div>
                <span>GO LIVE NOW</span>
              </button>
            </div>

            <div className="flex items-center gap-4 mt-4 text-[10px] text-neutral-400 font-medium">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                1080p 60FPS
              </span>
              <span>•</span>
              <span>Ultra-Low Latency</span>
              <span>•</span>
              <span>Dual Audio</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Streamer Stats Bar */}
      <div className="px-4 mb-4">
        <div className="grid grid-cols-3 gap-2 p-3 bg-neutral-900/60 rounded-2xl border border-neutral-800/80 text-center">
          <div>
            <p className="text-[10px] text-neutral-400 uppercase font-semibold">Total Views</p>
            <p className="text-sm font-black text-white mt-0.5">48.6K</p>
            <span className="text-[9px] text-emerald-400 font-bold flex items-center justify-center gap-0.5 mt-0.5">
              <TrendingUp className="w-2.5 h-2.5" /> +14%
            </span>
          </div>
          <div className="border-x border-neutral-800/80">
            <p className="text-[10px] text-neutral-400 uppercase font-semibold">Broadcast</p>
            <p className="text-sm font-black text-white mt-0.5">142h</p>
            <span className="text-[9px] text-neutral-400 font-medium mt-0.5 block">Total Live</span>
          </div>
          <div>
            <p className="text-[10px] text-neutral-400 uppercase font-semibold">Followers</p>
            <p className="text-sm font-black text-rose-400 mt-0.5">3.8K</p>
            <span className="text-[9px] text-emerald-400 font-bold flex items-center justify-center gap-0.5 mt-0.5">
              <TrendingUp className="w-2.5 h-2.5" /> +82 this wk
            </span>
          </div>
        </div>
      </div>

      {/* Popular Games Section */}
      <div className="mb-4">
        <div className="px-4 flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
              Popular Games
            </h3>
          </div>
          <button
            onClick={() => onNavigate('game_library')}
            className="text-[11px] text-rose-400 hover:text-rose-300 font-semibold flex items-center"
          >
            <span>Library</span>
            <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
          </button>
        </div>

        {/* Horizontal Game Cards */}
        <div className="flex gap-2.5 overflow-x-auto px-4 no-scrollbar pb-1">
          {games.slice(0, 5).map((game) => (
            <div
              key={game.id}
              onClick={() => {
                onSelectGame(game);
                onNavigate('start_live');
              }}
              className="group flex flex-col shrink-0 w-28 bg-neutral-900 hover:bg-neutral-800/80 border border-neutral-800 rounded-2xl p-2 cursor-pointer transition-all hover:border-rose-500/50"
            >
              <div className="relative w-full h-16 rounded-xl overflow-hidden mb-2 bg-neutral-800">
                <img
                  src={game.bannerUrl}
                  alt={game.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <span className="absolute bottom-1 left-1.5 text-[8px] font-bold text-rose-400 bg-black/60 px-1 py-0.5 rounded">
                  {game.category}
                </span>
              </div>
              <p className="text-[11px] font-bold text-neutral-200 truncate leading-snug">
                {game.name}
              </p>
              <span className="text-[9px] text-neutral-400 truncate mt-0.5">
                {game.activePlayers || 'Play & Cast'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Studio Quick Shortcuts */}
      <div className="px-4 mb-4">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onNavigate('scenes')}
            className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-900 hover:bg-neutral-800/80 border border-neutral-800/80 text-left transition-colors cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-200">Scene Presets</p>
              <p className="text-[10px] text-neutral-400">BRB & Intro layout</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('overlays')}
            className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-900 hover:bg-neutral-800/80 border border-neutral-800/80 text-left transition-colors cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-200">Live Overlays</p>
              <p className="text-[10px] text-neutral-400">Goals & Cam borders</p>
            </div>
          </button>
        </div>
      </div>

      {/* Stream History & Recent Streams */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
              Recent Streams
            </h3>
          </div>
          <button
            onClick={() => onNavigate('stream_history')}
            className="text-[11px] text-neutral-400 hover:text-white font-medium flex items-center"
          >
            <span>History</span>
            <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
          </button>
        </div>

        <div className="flex flex-col gap-2">
          {recentStreams.slice(0, 2).map((item) => (
            <div
              key={item.id}
              onClick={() => onNavigate('stream_history')}
              className="flex items-center gap-3 p-2.5 rounded-2xl bg-neutral-900/60 hover:bg-neutral-800/70 border border-neutral-800/80 cursor-pointer transition-colors"
            >
              <div className="relative w-16 h-12 rounded-xl overflow-hidden bg-neutral-800 shrink-0">
                <img src={item.thumbnailUrl} alt={item.title} className="w-full h-full object-cover" />
                <div className="absolute bottom-0.5 right-0.5 bg-black/80 px-1 py-0.2 rounded text-[8px] font-mono text-neutral-300">
                  {item.duration}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-neutral-200 truncate">{item.title}</p>
                <div className="flex items-center gap-2 mt-1 text-[10px] text-neutral-400">
                  <span>{item.game}</span>
                  <span>•</span>
                  <span className="flex items-center gap-0.5">
                    <Eye className="w-3 h-3 text-neutral-400" />
                    {item.totalViews} views
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  {item.performanceScore}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
