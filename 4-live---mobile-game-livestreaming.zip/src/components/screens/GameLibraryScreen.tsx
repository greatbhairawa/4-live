import React, { useState } from 'react';
import { GameItem } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Gamepad2,
  Search,
  Radio,
  PlusCircle,
  Flame,
  Check,
  Smartphone,
} from 'lucide-react';

interface GameLibraryScreenProps {
  onBack?: () => void;
  games: GameItem[];
  selectedGame: GameItem;
  onSelectGame: (game: GameItem) => void;
  onStartLiveWithGame: (game: GameItem) => void;
}

export const GameLibraryScreen: React.FC<GameLibraryScreenProps> = ({
  onBack,
  games,
  selectedGame,
  onSelectGame,
  onStartLiveWithGame,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredGames = games.filter(
    (g) =>
      g.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Game Library"
        subtitle="Supported Mobile Games & Screen Cast"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-3.5">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search mobile games or genres..."
            className="w-full bg-neutral-900 border border-neutral-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
          />
        </div>

        {/* Full Screen Cast Feature Card */}
        <div
          onClick={() => {
            const screenGame = games.find((g) => g.id === 'screen-other') || games[0];
            onSelectGame(screenGame);
            onStartLiveWithGame(screenGame);
          }}
          className="p-3.5 rounded-2xl bg-gradient-to-r from-rose-900/40 via-neutral-900 to-neutral-900 border border-rose-500/40 cursor-pointer hover:border-rose-500 transition-all flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Full Screen Cast (Any App)</h4>
              <p className="text-[10px] text-neutral-400">Stream any Android game or emulator</p>
            </div>
          </div>
          <button className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold">
            Stream
          </button>
        </div>

        {/* Games Grid */}
        <div className="flex flex-col gap-2">
          {filteredGames.map((game) => {
            const isSelected = selectedGame.id === game.id;
            return (
              <div
                key={game.id}
                onClick={() => onSelectGame(game)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-neutral-900 border-rose-500 shadow-md shadow-rose-500/10'
                    : 'bg-neutral-900/60 border-neutral-800 hover:bg-neutral-850'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={game.iconUrl}
                    alt={game.name}
                    className="w-12 h-12 rounded-xl object-cover border border-neutral-800 shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-neutral-100 truncate">{game.name}</h4>
                      {isSelected && (
                        <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                      )}
                    </div>
                    <span className="text-[10px] text-rose-400 font-semibold block truncate">
                      {game.category}
                    </span>
                    <span className="text-[9px] text-neutral-400 font-mono block truncate mt-0.5">
                      {game.packageId}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectGame(game);
                    onStartLiveWithGame(game);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-rose-600 hover:text-white text-neutral-300 text-[11px] font-bold border border-neutral-700 transition-colors shrink-0 ml-2"
                >
                  Go Live
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
