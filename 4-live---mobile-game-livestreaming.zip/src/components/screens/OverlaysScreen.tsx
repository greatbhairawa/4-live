import React from 'react';
import { OverlayConfig } from '../../types/stream';
import { HeaderBar } from '../common/HeaderBar';
import {
  Sparkles,
  Camera,
  Target,
  AtSign,
  Palette,
  Check,
} from 'lucide-react';

interface OverlaysScreenProps {
  onBack?: () => void;
  overlay: OverlayConfig;
  onUpdateOverlay: (newConfig: Partial<OverlayConfig>) => void;
}

export const OverlaysScreen: React.FC<OverlaysScreenProps> = ({
  onBack,
  overlay,
  onUpdateOverlay,
}) => {
  const borderPresets: { id: OverlayConfig['borderStyle']; name: string; color: string }[] = [
    { id: 'cyber', name: 'Cyber Crimson', color: '#F43F5E' },
    { id: 'stealth', name: 'Stealth Camo', color: '#10B981' },
    { id: 'crimson', name: 'Neon Cyber Blue', color: '#06B6D4' },
    { id: 'champion', name: 'Gold Champion', color: '#F59E0B' },
    { id: 'none', name: 'No Border', color: '#6B7280' },
  ];

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-y-auto">
      <HeaderBar
        title="Overlays & Widgets"
        subtitle="Theme Borders & Goal Tracker"
        onBack={onBack}
      />

      <div className="p-4 flex-1 flex flex-col gap-4">
        {/* Real-time Mini Canvas Preview */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-neutral-200">Overlay Preview</label>
            <span className="text-[10px] text-rose-400 font-medium">Real-time update</span>
          </div>

          <div className="relative w-full aspect-video bg-neutral-900 rounded-2xl overflow-hidden border border-neutral-800 flex flex-col justify-between p-3">
            {/* Background Sample Pattern */}
            <div className="absolute inset-0 bg-gradient-to-tr from-neutral-950 via-neutral-900 to-neutral-800 opacity-90" />

            {/* Selected Border Frame */}
            {overlay.borderStyle !== 'none' && (
              <div
                className="absolute inset-0 pointer-events-none border-4 rounded-2xl shadow-lg"
                style={{ borderColor: overlay.themeColor }}
              />
            )}

            {/* Goal Bar Preview */}
            {overlay.showGoalBar ? (
              <div className="relative z-10 px-2 py-1 rounded bg-black/80 border border-neutral-700/80 flex items-center justify-between text-[8px] max-w-[80%]">
                <span className="text-rose-400 font-bold truncate">{overlay.goalTitle}</span>
                <span className="font-mono text-neutral-300">
                  {overlay.goalCurrent} / {overlay.goalTarget}
                </span>
              </div>
            ) : (
              <div />
            )}

            {/* Facecam Frame Preview */}
            <div
              className={`absolute z-10 w-12 h-12 bg-neutral-800 border-2 flex items-center justify-center text-[7px] font-mono text-rose-400 ${
                overlay.camShape === 'circle'
                  ? 'rounded-full'
                  : 'rounded-xl'
              } ${
                overlay.camPosition === 'top_left'
                  ? 'top-2 left-2'
                  : overlay.camPosition === 'bottom_left'
                  ? 'bottom-2 left-2'
                  : overlay.camPosition === 'bottom_right'
                  ? 'bottom-2 right-2'
                  : 'top-2 right-2'
              }`}
              style={{ borderColor: overlay.themeColor }}
            >
              <Camera className="w-3.5 h-3.5" />
            </div>

            {/* Social Handle Banner Preview */}
            {overlay.showSocials && (
              <div className="relative z-10 self-start px-2 py-0.5 rounded bg-black/80 border border-neutral-800 text-[8px] font-mono text-rose-400">
                {overlay.socialHandle}
              </div>
            )}
          </div>
        </div>

        {/* Theme Border Selection */}
        <div>
          <label className="text-xs font-bold text-neutral-200 mb-1.5 block">
            Stream Frame Style
          </label>
          <div className="grid grid-cols-2 gap-2">
            {borderPresets.map((b) => {
              const isSelected = overlay.borderStyle === b.id;
              return (
                <button
                  key={b.id}
                  onClick={() =>
                    onUpdateOverlay({ borderStyle: b.id, themeColor: b.color })
                  }
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-neutral-900 border-rose-500 text-white font-bold'
                      : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0"
                    style={{ backgroundColor: b.color }}
                  />
                  <span className="text-xs truncate">{b.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Follower / Donation Goal Widget */}
        <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-3.5 flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-rose-400" />
              <label className="text-xs font-bold text-neutral-200">Goal Bar Widget</label>
            </div>
            <button
              onClick={() => onUpdateOverlay({ showGoalBar: !overlay.showGoalBar })}
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                overlay.showGoalBar ? 'bg-rose-500' : 'bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  overlay.showGoalBar ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {overlay.showGoalBar && (
            <div className="flex flex-col gap-2 pt-1 border-t border-neutral-800">
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Goal Title</label>
                <input
                  type="text"
                  value={overlay.goalTitle}
                  onChange={(e) => onUpdateOverlay({ goalTitle: e.target.value })}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Current Value</label>
                  <input
                    type="number"
                    value={overlay.goalCurrent}
                    onChange={(e) => onUpdateOverlay({ goalCurrent: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Target Value</label>
                  <input
                    type="number"
                    value={overlay.goalTarget}
                    onChange={(e) => onUpdateOverlay({ goalTarget: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Social Handle Ticker */}
        <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-3.5 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AtSign className="w-4 h-4 text-cyan-400" />
              <label className="text-xs font-bold text-neutral-200">Social Ticker</label>
            </div>
            <button
              onClick={() => onUpdateOverlay({ showSocials: !overlay.showSocials })}
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                overlay.showSocials ? 'bg-cyan-500' : 'bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  overlay.showSocials ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {overlay.showSocials && (
            <input
              type="text"
              value={overlay.socialHandle}
              onChange={(e) => onUpdateOverlay({ socialHandle: e.target.value })}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
            />
          )}
        </div>
      </div>
    </div>
  );
};
