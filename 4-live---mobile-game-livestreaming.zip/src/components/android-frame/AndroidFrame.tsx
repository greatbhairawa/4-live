import React from 'react';
import { Wifi, Battery, Signal, RotateCw } from 'lucide-react';
import { OrientationMode } from '../../types/stream';

interface AndroidFrameProps {
  children: React.ReactNode;
  orientation: OrientationMode;
  onToggleOrientation: () => void;
  isStreaming?: boolean;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  orientation,
  onToggleOrientation,
  isStreaming = false,
}) => {
  const isLandscape = orientation === 'landscape';

  return (
    <div className="relative flex flex-col items-center justify-center p-2 sm:p-4 select-none">
      {/* Top Device Orientation Switcher & Mode Indicator */}
      <div className="flex items-center justify-between w-full max-w-[420px] mb-2 px-2 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-semibold text-neutral-300">Android 15 Device Emulation</span>
          {isStreaming && (
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-600/30 text-rose-400 font-mono uppercase tracking-wider font-bold border border-rose-500/30">
              Live Broadcast Active
            </span>
          )}
        </div>
        <button
          onClick={onToggleOrientation}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800/80 hover:bg-neutral-700/80 text-neutral-300 hover:text-white transition-all border border-neutral-700/50 cursor-pointer shadow-sm text-[11px]"
          title="Toggle Portrait / Landscape Mode"
        >
          <RotateCw className="w-3.5 h-3.5 text-rose-400" />
          <span>{isLandscape ? 'Landscape (16:9)' : 'Portrait (9:16)'}</span>
        </button>
      </div>

      {/* Outer Phone Bezel */}
      <div
        className={`relative transition-all duration-300 ease-out bg-neutral-900 border-4 border-neutral-800 rounded-[44px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8),0_0_20px_rgba(244,63,94,0.12)] p-2.5 overflow-hidden ${
          isLandscape
            ? 'w-[780px] max-w-[94vw] h-[460px]'
            : 'w-[390px] max-w-[96vw] h-[810px]'
        }`}
      >
        {/* Inner Phone Screen */}
        <div className="relative w-full h-full bg-neutral-950 rounded-[34px] overflow-hidden flex flex-col border border-neutral-800/60 shadow-inner">
          
          {/* Android Status Bar */}
          <div className="h-7 w-full px-5 flex items-center justify-between text-[11px] font-medium text-neutral-300 z-50 bg-neutral-950/80 backdrop-blur-md shrink-0">
            <span className="font-mono tracking-tight font-semibold">11:05</span>

            {/* Dynamic Camera Punch-hole */}
            <div className="absolute left-1/2 -translate-x-1/2 top-1.5 w-3.5 h-3.5 bg-neutral-900 rounded-full border border-neutral-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-neutral-950 rounded-full" />
            </div>

            <div className="flex items-center gap-1.5 text-neutral-400">
              <Signal className="w-3 h-3 text-neutral-300" />
              <Wifi className="w-3 h-3 text-neutral-300" />
              <div className="flex items-center gap-0.5 font-mono text-[10px] text-neutral-300">
                <span>94%</span>
                <Battery className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/20" />
              </div>
            </div>
          </div>

          {/* Screen Content Container */}
          <div className="relative flex-1 w-full overflow-hidden flex flex-col">
            {children}
          </div>

          {/* Android Gesture Navigation Pill */}
          <div className="h-4 w-full flex items-center justify-center bg-neutral-950 shrink-0 z-50">
            <div className="w-28 h-1 bg-neutral-600/70 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
