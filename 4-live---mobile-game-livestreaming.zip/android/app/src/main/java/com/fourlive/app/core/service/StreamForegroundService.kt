package com.fourlive.app.core.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.fourlive.app.MainActivity
import com.fourlive.app.R

/**
 * 4 LIVE - Broadcast Foreground Service
 * Keeps screen recording and audio streaming active even when the user minimizes 4 LIVE
 * to play their mobile games.
 */
class StreamForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "fourlive_broadcast_channel"
        const val NOTIFICATION_ID = 4040
        const val ACTION_START = "com.fourlive.ACTION_START"
        const val ACTION_STOP = "com.fourlive.ACTION_STOP"
        const val ACTION_TOGGLE_MIC = "com.fourlive.ACTION_TOGGLE_MIC"
        const val ACTION_PAUSE = "com.fourlive.ACTION_PAUSE"

        fun start(context: Context) {
            val intent = Intent(context, StreamForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, StreamForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundWithTypes()
            }
            ACTION_STOP -> {
                stopForegroundStream()
            }
            ACTION_TOGGLE_MIC -> {
                // Broadcast mic toggle to engine
            }
            ACTION_PAUSE -> {
                // Broadcast pause to engine
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithTypes() {
        val notification = buildBroadcastNotification("4 LIVE is broadcasting your screen", "Playing PUBG Mobile • 1080p 60fps")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                serviceTypes = serviceTypes or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            startForeground(NOTIFICATION_ID, notification, serviceTypes)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildBroadcastNotification(title: String, statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, StreamForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "End Stream", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "4 LIVE Active Broadcast",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status, bitrate, and controls during active screen broadcast."
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "4Live::BroadcastWakeLock").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L) // 12 hours max safety limit
        }
    }

    private fun stopForegroundStream() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopForegroundStream()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
