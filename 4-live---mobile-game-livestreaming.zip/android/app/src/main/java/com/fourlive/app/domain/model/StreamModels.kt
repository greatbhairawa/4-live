package com.fourlive.app.domain.model

sealed class StreamState {
    object Idle : StreamState()
    object Preparing : StreamState()
    object Ready : StreamState()
    object Connecting : StreamState()
    data class Streaming(val startTimeMillis: Long, val resolution: String, val fps: Int) : StreamState()
    object Paused : StreamState()
    object Ended : StreamState()
    data class Error(val message: String) : StreamState()
}

data class StreamMetrics(
    val bitrateKbps: Int = 0,
    val fps: Int = 0,
    val droppedFrames: Int = 0,
    val uptimeSeconds: Long = 0L,
    val viewers: Int = 0,
    val isNetworkWeak: Boolean = false
)

data class StreamConfig(
    val title: String = "",
    val description: String = "",
    val gameId: String = "",
    val resolutionWidth: Int = 1920,
    val resolutionHeight: Int = 1080,
    val fps: Int = 60,
    val targetBitrateKbps: Int = 5000,
    val keyframeInterval: Int = 2,
    val isLandscape: Boolean = true,
    val micEnabled: Boolean = true,
    val gameAudioEnabled: Boolean = true,
    val cameraEnabled: Boolean = true
)

enum class PlatformType(val displayName: String) {
    YOUTUBE("YouTube Gaming"),
    TWITCH("Twitch"),
    KICK("KICK"),
    FACEBOOK("Facebook Gaming"),
    CUSTOM_RTMP("Custom RTMP")
}

data class StreamAccount(
    val platform: PlatformType,
    val username: String = "",
    val isConnected: Boolean = false,
    val rtmpUrl: String = "",
    val isKeySaved: Boolean = false
)

data class GameCategory(
    val id: String,
    val name: String,
    val genre: String,
    val iconRes: String,
    val isInstalled: Boolean = true
)

data class OverlayPreset(
    val id: String,
    val name: String,
    val themeColorHex: String,
    val borderStyle: String,
    val showChatOverlay: Boolean,
    val showDonationGoal: Boolean,
    val showSocialHandle: Boolean
)
