package com.fourlive.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.fourlive.app.core.engine.DefaultStreamEngine
import com.fourlive.app.core.service.StreamForegroundService

class MainActivity : ComponentActivity() {

    private lateinit var streamEngine: DefaultStreamEngine
    private lateinit var projectionManager: MediaProjectionManager

    // Permission launcher for Android MediaProjection Screen Capture
    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            streamEngine.initialize(this, result.resultCode, result.data!!)
            StreamForegroundService.start(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        streamEngine = DefaultStreamEngine(this)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Compose NavHost with 16 screens:
                    // Splash, Auth, Home, StartLive, PlatformSelect, StreamSettings,
                    // LivePreview, LiveStreaming, CreatorStudio, Scenes, Overlays,
                    // Chat, GameLibrary, StreamHistory, Profile, Settings.
                }
            }
        }
    }

    fun requestScreenBroadcastConsent() {
        val captureIntent = projectionManager.createScreenCaptureIntent()
        mediaProjectionLauncher.launch(captureIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        streamEngine.cleanup()
    }
}
