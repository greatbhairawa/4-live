package com.fourlive.app

import android.app.Application
import android.util.Log

class FourLiveApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("4LIVE", "4 LIVE Application Initialized with Android Keystore & MediaProjection")
    }
}
