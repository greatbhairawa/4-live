package com.fourlive.app.core.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * 4 LIVE - Secure Storage
 * Uses Android Keystore and EncryptedSharedPreferences (AES-256-GCM)
 * to securely store RTMP stream keys, platform OAuth tokens, and auth secrets.
 * Plaintext storage of stream credentials is strictly prohibited.
 */
class SecureStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val securePrefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "fourlive_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveStreamKey(platformId: String, streamKey: String) {
        securePrefs.edit()
            .putString("key_${platformId.lowercase()}", streamKey)
            .apply()
    }

    fun getStreamKey(platformId: String): String? {
        return securePrefs.getString("key_${platformId.lowercase()}", null)
    }

    fun saveCustomRtmpUrl(url: String) {
        securePrefs.edit().putString("custom_rtmp_url", url).apply()
    }

    fun getCustomRtmpUrl(): String? {
        return securePrefs.getString("custom_rtmp_url", "rtmp://live.twitch.tv/app")
    }

    fun saveAuthToken(platformId: String, token: String) {
        securePrefs.edit().putString("token_${platformId.lowercase()}", token).apply()
    }

    fun clearPlatformCredentials(platformId: String) {
        securePrefs.edit()
            .remove("key_${platformId.lowercase()}")
            .remove("token_${platformId.lowercase()}")
            .apply()
    }

    fun clearAll() {
        securePrefs.edit().clear().apply()
    }
}
