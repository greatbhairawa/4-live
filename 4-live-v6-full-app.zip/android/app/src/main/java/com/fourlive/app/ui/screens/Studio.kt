package com.fourlive.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material.icons.filled.Send
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fourlive.app.ui.AppState
import com.fourlive.app.ui.ChatMsg
import com.fourlive.app.ui.SCENES
import com.fourlive.app.ui.Screen
import com.fourlive.app.ui.components.Card1
import com.fourlive.app.ui.components.Chip
import com.fourlive.app.ui.components.GhostButton
import com.fourlive.app.ui.components.Muted
import com.fourlive.app.ui.components.Pill
import com.fourlive.app.ui.components.SectionTitle
import com.fourlive.app.ui.components.StatBox
import com.fourlive.app.ui.components.SwitchRow
import com.fourlive.app.ui.components.TopBar
import com.fourlive.app.ui.theme.Pal

private val OVERLAY_COLORS = listOf(
    "Crimson" to Color(0xFFF43F5E),
    "Cyber" to Color(0xFF22D3EE),
    "Neon" to Color(0xFF34D399),
    "Champion" to Color(0xFFF59E0B),
    "Violet" to Color(0xFF8B5CF6)
)

// 9. Creator Studio (analytics, abhi demo data + asli session history)
@Composable
fun CreatorStudioScreen(app: AppState) {
    val totalViews = app.history.sumOf { it.views }
    val bestPeak = app.history.maxOfOrNull { it.peak } ?: 0
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopBar("Creator Studio", onBack = null)
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatBox("Streams", "${app.history.size}", Modifier.weight(1f), Pal.Rose)
                StatBox("Total views", "$totalViews", Modifier.weight(1f), Pal.Cyan)
                StatBox("Peak viewers", "$bestPeak", Modifier.weight(1f), Pal.Emerald)
            }
            Muted("Numbers abhi demo sample hain. Asli analytics Version 2.0 mein.", 11)

            SectionTitle("Creator controls")
            GhostButton("Scenes", onClick = { app.goTab(Screen.SCENES) })
            GhostButton("Overlays", onClick = { app.navigate(Screen.OVERLAYS) })
            GhostButton("Live Chat", onClick = { app.navigate(Screen.CHAT) })
            GhostButton("Stream History", onClick = { app.navigate(Screen.STREAM_HISTORY) })

            SectionTitle("Achievements")
            Achievement("First stream", "Pehli baar live jao", app.history.any { it.date != "Demo sample" })
            Achievement("100 viewers", "Ek stream mein 100 viewers", bestPeak >= 100)
            Achievement("Multi-platform", "2 ya zyada platform par live", false)
        }
    }
}

@Composable
private fun Achievement(title: String, subtitle: String, done: Boolean) {
    Card1 {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(
                if (done) Icons.Filled.Check else Icons.Filled.EmojiEvents,
                contentDescription = null,
                tint = if (done) Pal.Emerald else Pal.N500
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Pal.Text)
                Muted(subtitle)
            }
            if (done) Pill("Done", Pal.Emerald)
        }
    }
}

// 10. Scenes
@Composable
fun ScenesScreen(app: AppState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopBar("Scenes", onBack = null)
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Muted("Scene chuno. Live ke dauraan scene badalna Version 1.2 mein aayega.", 13)
            SCENES.forEach { s ->
                val active = app.activeScene == s.id
                Card1(borderColor = if (active) Pal.Rose else Pal.N800, onClick = { app.activeScene = s.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(s.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                            Muted(s.tagline)
                        }
                        if (active) Pill("Active", Pal.Rose)
                    }
                }
            }
            GhostButton("Edit overlays", onClick = { app.navigate(Screen.OVERLAYS) })
        }
    }
}

// 11. Overlays (text, image, GIF: abhi theme/goal/social; image aur GIF Version 1.2)
@Composable
fun OverlaysScreen(app: AppState) {
    val accent = OVERLAY_COLORS[app.overlayColorIndex].second
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Overlays", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(app.game.colorA, app.game.colorB)))
                    .border(2.dp, accent, RoundedCornerShape(16.dp))
            ) {
                val camAlign = when (app.camPosition) {
                    "Top left" -> Alignment.TopStart
                    "Bottom left" -> Alignment.BottomStart
                    "Bottom right" -> Alignment.BottomEnd
                    else -> Alignment.TopEnd
                }
                Box(
                    modifier = Modifier
                        .align(camAlign)
                        .padding(10.dp)
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .border(2.dp, accent, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("CAM", fontSize = 10.sp, color = Color.White) }

                if (app.showSocials) {
                    Text(
                        app.socialHandle,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White
                    )
                }
                if (app.showGoalBar) {
                    val frac = (app.goalCurrent.toFloat() / app.goalTarget.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp)
                            .fillMaxWidth(0.5f)
                    ) {
                        Text(app.goalTitle, fontSize = 10.sp, color = Color.White)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.White.copy(alpha = 0.25f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(frac)
                                    .height(6.dp)
                                    .background(accent)
                            )
                        }
                    }
                }
            }
            Muted("Preview. Overlay abhi sirf design hai, live stream mein jodna Version 1.2 mein aayega.", 11)

            SectionTitle("Theme color")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OVERLAY_COLORS.forEachIndexed { i, (name, _) ->
                    Chip(name, app.overlayColorIndex == i) { app.overlayColorIndex = i }
                }
            }

            SectionTitle("Camera position")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Top left", "Top right").forEach { p -> Chip(p, app.camPosition == p) { app.camPosition = p } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Bottom left", "Bottom right").forEach { p -> Chip(p, app.camPosition == p) { app.camPosition = p } }
            }

            SwitchRow("Goal bar", "Donation ya follower goal dikhao", app.showGoalBar) { app.showGoalBar = it }
            if (app.showGoalBar) {
                OutlinedTextField(
                    value = app.goalTitle, onValueChange = { app.goalTitle = it },
                    label = { Text("Goal title") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
            SwitchRow("Social handle", "Apna handle dikhao", app.showSocials) { app.showSocials = it }
            if (app.showSocials) {
                OutlinedTextField(
                    value = app.socialHandle, onValueChange = { app.socialHandle = it },
                    label = { Text("Handle") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
            Muted("Text, image, GIF aur stickers Version 1.2 mein jodenge.", 11)
        }
    }
}

// 12. Live Chat (demo messages, platform chat Version 1.2 mein)
@Composable
fun ChatScreen(app: AppState) {
    var input by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Live Chat", onBack = { app.back() })
        Muted("  Demo chat. Asli viewers ka chat Version 1.2 mein platforms se judega.", 11)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            app.chat.forEach { m: ChatMsg ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(m.sender, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = m.color)
                    Text(m.text, fontSize = 13.sp, color = Pal.N300)
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                placeholder = { Text("Message likho") }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    app.chat.add(ChatMsg(app.userName, input.trim(), Pal.Rose))
                    input = ""
                }
            }) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = Pal.Rose)
            }
        }
    }
}
