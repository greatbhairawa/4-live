package com.fourlive.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.fourlive.app.core.security.SecureStorage

enum class Screen {
    SPLASH, AUTH, HOME, START_LIVE, PLATFORM_SELECT, STREAM_SETTINGS, LIVE_PREVIEW,
    LIVE_STREAMING, CREATOR_STUDIO, SCENES, OVERLAYS, CHAT, GAME_LIBRARY,
    STREAM_HISTORY, PROFILE, SETTINGS
}

data class Game(
    val id: String,
    val name: String,
    val category: String,
    val players: String,
    val colorA: Color,
    val colorB: Color
)

data class SceneItem(val id: String, val name: String, val tagline: String)

data class PastStream(
    val title: String,
    val game: String,
    val date: String,
    val duration: String,
    val views: Int,
    val peak: Int,
    val platforms: String,
    val score: Int
)

data class ChatMsg(val sender: String, val text: String, val color: Color)

class PlatformEntry(
    val id: String,
    val name: String,
    val color: Color,
    val hint: String,
    initialUrl: String
) {
    var url by mutableStateOf(initialUrl)
    var key by mutableStateOf("")
    var selected by mutableStateOf(false)
    val ready: Boolean get() = url.isNotBlank() && key.isNotBlank()
}

val GAMES = listOf(
    Game("pubg", "PUBG Mobile", "Battle Royale", "Popular", Color(0xFFB45309), Color(0xFF451A03)),
    Game("ff", "Free Fire MAX", "Survival Shooter", "Popular", Color(0xFFDC2626), Color(0xFF450A0A)),
    Game("codm", "Call of Duty: Mobile", "Action / FPS", "Popular", Color(0xFF15803D), Color(0xFF052E16)),
    Game("mlbb", "Mobile Legends", "5v5 MOBA", "Popular", Color(0xFF1D4ED8), Color(0xFF172554)),
    Game("genshin", "Genshin Impact", "Open World RPG", "Popular", Color(0xFF7C3AED), Color(0xFF2E1065)),
    Game("brawl", "Brawl Stars", "Fast Action", "Popular", Color(0xFFCA8A04), Color(0xFF422006)),
    Game("screen", "Any Game / Full Screen", "General screen broadcast", "All apps", Color(0xFF0E7490), Color(0xFF083344))
)

val SCENES = listOf(
    SceneItem("game", "Gameplay Main", "Full game view with cam and social handle"),
    SceneItem("start", "Starting Soon", "Warm-up screen before the broadcast starts"),
    SceneItem("brb", "Be Right Back", "Break screen while you step away"),
    SceneItem("chat", "Just Chatting", "Large facecam with big chat"),
    SceneItem("end", "Stream Ending", "Outro and social links")
)

val SAMPLE_CHAT = listOf(
    ChatMsg("RiyaPlays", "Nice play! 🔥", Color(0xFFF43F5E)),
    ChatMsg("Aarav_07", "Audio bilkul clear aa rahi hai", Color(0xFF22D3EE)),
    ChatMsg("KingRohit", "Next match kab?", Color(0xFFF59E0B)),
    ChatMsg("Sneha.live", "Overlay mast hai", Color(0xFF34D399)),
    ChatMsg("Mod_Vikram", "Welcome everyone, drop your gamer tags", Color(0xFF8B5CF6))
)

val SAMPLE_HISTORY = listOf(
    PastStream("Ranked push to Conqueror", "PUBG Mobile", "Demo sample", "2h 45m", 3840, 412, "YouTube, Twitch", 94),
    PastStream("Mythical Glory grind", "Mobile Legends", "Demo sample", "3h 12m", 5210, 680, "YouTube", 98),
    PastStream("Tournament semi-finals", "Call of Duty: Mobile", "Demo sample", "1h 50m", 2900, 330, "Twitch, Kick", 89)
)

fun fmtDuration(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

class AppState(private val storage: SecureStorage?) {

    // ---- Navigation ----
    val stack = mutableStateListOf(Screen.SPLASH)
    val screen: Screen get() = stack.last()

    fun navigate(s: Screen) {
        if (stack.last() != s) stack.add(s)
    }

    fun replace(s: Screen) {
        stack.clear()
        stack.add(s)
    }

    fun goTab(s: Screen) {
        stack.clear()
        if (s != Screen.HOME) stack.add(Screen.HOME)
        stack.add(s)
    }

    fun back(): Boolean {
        return if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            true
        } else false
    }

    // ---- Profile (sirf is phone par save hota hai) ----
    var loggedIn by mutableStateOf(false)
    var userName by mutableStateOf("Streamer")
    var email by mutableStateOf("")

    // ---- Stream session ----
    var title by mutableStateOf("My first 4 LIVE stream")
    var description by mutableStateOf("Live gameplay. Drop your gamer tags in chat!")
    var game by mutableStateOf(GAMES[0])
    var privacy by mutableStateOf("Public")
    var tags by mutableStateOf("4Live, Gaming, Mobile")

    val platforms = listOf(
        PlatformEntry("youtube", "YouTube Gaming", Color(0xFFFF0000),
            "YouTube Studio > Go Live > Stream > Stream key", "rtmp://a.rtmp.youtube.com/live2"),
        PlatformEntry("twitch", "Twitch", Color(0xFF9146FF),
            "Twitch Dashboard > Settings > Stream > Primary stream key", "rtmp://live.twitch.tv/app"),
        PlatformEntry("kick", "KICK", Color(0xFF53FC18),
            "Kick Dashboard > Settings > Stream URL & key (URL dashboard se copy karo)",
            "rtmps://fa723fc1b171.global-contribute.live-video.net/app"),
        PlatformEntry("facebook", "Facebook Gaming", Color(0xFF1877F2),
            "Facebook Live Producer > Streaming software > Stream key (har live ke liye nayi key)",
            "rtmps://live-api-s.facebook.com:443/rtmp/"),
        PlatformEntry("custom", "Custom RTMP / Relay", Color(0xFFF43F5E),
            "Apna RTMP server ya relay service ka URL aur key", "")
    )

    // ---- Stream settings ----
    var resolution by mutableStateOf(720)       // 480 / 720 / 1080
    var fps by mutableStateOf(30)               // 30 / 60
    var autoBitrate by mutableStateOf(true)
    var manualBitrateKbps by mutableStateOf(3000)
    var landscape by mutableStateOf(true)
    var mic by mutableStateOf(true)
    var gameAudio by mutableStateOf(true)
    var camera by mutableStateOf(false)
    var audioBitrateKbps by mutableStateOf(128)
    var wifiOnly by mutableStateOf(false)

    // ---- Scenes / overlays ----
    var activeScene by mutableStateOf(SCENES[0].id)
    var overlayColorIndex by mutableStateOf(0)
    var showGoalBar by mutableStateOf(true)
    var goalTitle by mutableStateOf("Next stream upgrade")
    var goalCurrent by mutableStateOf(340)
    var goalTarget by mutableStateOf(500)
    var showSocials by mutableStateOf(true)
    var socialHandle by mutableStateOf("@4LIVE_streamer")
    var camPosition by mutableStateOf("Top right")

    // ---- Chat (demo) ----
    val chat = mutableStateListOf<ChatMsg>().apply { addAll(SAMPLE_CHAT) }

    // ---- History ----
    val history = mutableStateListOf<PastStream>().apply { addAll(SAMPLE_HISTORY) }
    var liveStartMs by mutableStateOf(0L)

    val resolutionWidth: Int get() = when (resolution) { 480 -> 854; 1080 -> 1920; else -> 1280 }
    val resolutionHeight: Int get() = resolution

    fun videoWidth() = if (landscape) resolutionWidth else resolutionHeight
    fun videoHeight() = if (landscape) resolutionHeight else resolutionWidth

    fun videoBitrateKbps(): Int {
        if (!autoBitrate) return manualBitrateKbps
        return when (resolution) {
            480 -> 1500
            1080 -> if (fps == 60) 6000 else 4500
            else -> if (fps == 60) 3500 else 2500
        }
    }

    fun selectedPlatforms() = platforms.filter { it.selected }

    /** Abhi engine ek hi destination par bhejta hai: pehla selected jisme URL aur key hai. */
    fun primaryDestination(): PlatformEntry? = selectedPlatforms().firstOrNull { it.ready }

    // ---- Persistence (encrypted) ----
    fun load() {
        val st = storage ?: return
        runCatching {
            userName = st.get("profile_name") ?: userName
            email = st.get("profile_email") ?: email
            loggedIn = st.get("profile_name") != null
            platforms.forEach { p ->
                st.get("url_${p.id}")?.let { p.url = it }
                st.get("key_${p.id}")?.let { p.key = it }
                p.selected = st.get("sel_${p.id}") == "1"
            }
        }
    }

    fun saveProfile() {
        runCatching {
            storage?.put("profile_name", userName)
            storage?.put("profile_email", email)
        }
    }

    fun savePlatforms() {
        runCatching {
            platforms.forEach { p ->
                storage?.put("url_${p.id}", p.url)
                storage?.put("key_${p.id}", p.key)
                storage?.put("sel_${p.id}", if (p.selected) "1" else "0")
            }
        }
    }

    fun clearKeys() {
        runCatching {
            platforms.forEach { p ->
                storage?.remove("key_${p.id}")
                p.key = ""
            }
        }
    }

    fun logout() {
        runCatching {
            storage?.remove("profile_name")
            storage?.remove("profile_email")
        }
        loggedIn = false
        userName = "Streamer"
        email = ""
    }
}
