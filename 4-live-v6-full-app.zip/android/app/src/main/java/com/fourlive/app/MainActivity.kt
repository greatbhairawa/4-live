package com.fourlive.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.fourlive.app.core.engine.Phase
import com.fourlive.app.core.engine.StreamStatus
import com.fourlive.app.core.security.SecureStorage
import com.fourlive.app.core.service.StreamForegroundService
import com.fourlive.app.ui.AppState
import com.fourlive.app.ui.PastStream
import com.fourlive.app.ui.Screen
import com.fourlive.app.ui.components.BottomNav
import com.fourlive.app.ui.fmtDuration
import com.fourlive.app.ui.screens.AuthScreen
import com.fourlive.app.ui.screens.ChatScreen
import com.fourlive.app.ui.screens.CreatorStudioScreen
import com.fourlive.app.ui.screens.GameLibraryScreen
import com.fourlive.app.ui.screens.HomeScreen
import com.fourlive.app.ui.screens.LivePreviewScreen
import com.fourlive.app.ui.screens.LiveStreamingScreen
import com.fourlive.app.ui.screens.OverlaysScreen
import com.fourlive.app.ui.screens.PlatformSelectScreen
import com.fourlive.app.ui.screens.ProfileScreen
import com.fourlive.app.ui.screens.ScenesScreen
import com.fourlive.app.ui.screens.SettingsScreen
import com.fourlive.app.ui.screens.SplashScreen
import com.fourlive.app.ui.screens.StartLiveScreen
import com.fourlive.app.ui.screens.StreamHistoryScreen
import com.fourlive.app.ui.screens.StreamSettingsScreen
import com.fourlive.app.ui.theme.FourLiveTheme
import com.fourlive.app.ui.theme.Pal

class MainActivity : ComponentActivity() {

    private lateinit var app: AppState

    // Capture shuru hone se pehle ki values
    private var pUrl = ""
    private var pKey = ""
    private var pWidth = 1280
    private var pHeight = 720
    private var pFps = 30
    private var pVideoKbps = 2500
    private var pAudioKbps = 128
    private var pMic = true
    private var pGame = true

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            app.liveStartMs = 0L
            StreamStatus.set(Phase.CONNECTING, "Connecting...")
            StreamForegroundService.start(
                this, result.resultCode, data,
                pUrl, pKey, pWidth, pHeight, pFps, pVideoKbps, pAudioKbps, pMic, pGame
            )
            app.navigate(Screen.LIVE_STREAMING)
        } else {
            StreamStatus.set(Phase.IDLE, "")
            Toast.makeText(this, "Screen capture permission nahi di gayi", Toast.LENGTH_LONG).show()
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Mic permission na mile to sirf game audio jayega
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun onWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun beginStream() {
        val dest = app.primaryDestination()
        if (dest == null) {
            Toast.makeText(this, "Koi platform ready nahi: URL aur stream key daalo", Toast.LENGTH_LONG).show()
            return
        }
        if (app.wifiOnly && !onWifi()) {
            Toast.makeText(this, "Sirf WiFi mode on hai, WiFi se connect karo", Toast.LENGTH_LONG).show()
            return
        }
        app.savePlatforms()

        pUrl = dest.url.trim()
        pKey = dest.key.trim()
        pWidth = app.videoWidth()
        pHeight = app.videoHeight()
        pFps = app.fps
        pVideoKbps = app.videoBitrateKbps()
        pAudioKbps = app.audioBitrateKbps
        pMic = app.mic
        pGame = app.gameAudio

        StreamStatus.set(Phase.CONNECTING, "Permissions...")
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isEmpty()) requestScreenCapture() else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun endStream() {
        val phase = StreamStatus.state.value.phase
        if (phase == Phase.LIVE || phase == Phase.CONNECTING) {
            if (phase == Phase.LIVE && app.liveStartMs > 0L) {
                val secs = (System.currentTimeMillis() - app.liveStartMs) / 1000
                app.history.add(
                    0,
                    PastStream(
                        title = app.title,
                        game = app.game.name,
                        date = "Just now",
                        duration = fmtDuration(secs),
                        views = 0,
                        peak = 0,
                        platforms = app.primaryDestination()?.name ?: "-",
                        score = 0
                    )
                )
            }
            StreamForegroundService.stop(this)
        }
        StreamStatus.set(Phase.IDLE, "")
        app.liveStartMs = 0L
        app.replace(Screen.HOME)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val storage = runCatching { SecureStorage(this) }.getOrNull()
        app = AppState(storage)
        app.load()

        setContent {
            FourLiveTheme {
                AppRoot(app, onGoLive = { beginStream() }, onEnd = { endStream() })
            }
        }
    }
}

private val TAB_SCREENS = setOf(
    Screen.HOME, Screen.GAME_LIBRARY, Screen.SCENES, Screen.CREATOR_STUDIO, Screen.PROFILE
)

@Composable
private fun AppRoot(app: AppState, onGoLive: () -> Unit, onEnd: () -> Unit) {
    val screen = app.screen

    // Back: live ke dauraan galti se bahar na jao
    BackHandler(enabled = app.stack.size > 1) { app.back() }
    BackHandler(enabled = screen == Screen.LIVE_STREAMING) { }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Pal.Bg)
            .systemBarsPadding()
            .imePadding()
    ) {
        Box(modifier = Modifier.weight(1f)) {
            when (screen) {
                Screen.SPLASH -> SplashScreen(app)
                Screen.AUTH -> AuthScreen(app)
                Screen.HOME -> HomeScreen(app)
                Screen.START_LIVE -> StartLiveScreen(app)
                Screen.PLATFORM_SELECT -> PlatformSelectScreen(app)
                Screen.STREAM_SETTINGS -> StreamSettingsScreen(
                    app,
                    fromWizard = app.stack.getOrNull(app.stack.size - 2) == Screen.PLATFORM_SELECT
                )
                Screen.LIVE_PREVIEW -> LivePreviewScreen(app, onGoLive)
                Screen.LIVE_STREAMING -> LiveStreamingScreen(app, onEnd)
                Screen.CREATOR_STUDIO -> CreatorStudioScreen(app)
                Screen.SCENES -> ScenesScreen(app)
                Screen.OVERLAYS -> OverlaysScreen(app)
                Screen.CHAT -> ChatScreen(app)
                Screen.GAME_LIBRARY -> GameLibraryScreen(app)
                Screen.STREAM_HISTORY -> StreamHistoryScreen(app)
                Screen.PROFILE -> ProfileScreen(app)
                Screen.SETTINGS -> SettingsScreen(app)
            }
        }
        if (screen in TAB_SCREENS) {
            BottomNav(screen) { app.goTab(it) }
        }
    }
}
