package com.fourlive.app.core.service

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.fourlive.app.MainActivity
import com.fourlive.app.core.engine.Phase
import com.fourlive.app.core.engine.StreamStatus
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.InternalAudioSource
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.encoder.input.sources.audio.MixAudioSource
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.library.generic.GenericStream

/**
 * 4 LIVE - asli streaming service.
 * MediaProjection (screen) + mic + internal (game) audio -> RTMP/RTMPS.
 * Android 14/15 rule: pehle startForeground(), phir MediaProjection banao.
 */
class StreamForegroundService : Service() {

    companion object {
        private const val TAG = "4Live_Service"
        const val CHANNEL_ID = "fourlive_broadcast_channel"
        const val NOTIFICATION_ID = 4040
        const val ACTION_START = "com.fourlive.ACTION_START"
        const val ACTION_STOP = "com.fourlive.ACTION_STOP"

        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_DATA = "projection_data"
        private const val EXTRA_URL = "rtmp_url"
        private const val EXTRA_KEY = "stream_key"
        private const val EXTRA_WIDTH = "width"
        private const val EXTRA_HEIGHT = "height"
        private const val EXTRA_FPS = "fps"
        private const val EXTRA_AUDIO_KBPS = "audio_kbps"
        private const val EXTRA_MIC = "mic"
        private const val EXTRA_GAME_AUDIO = "game_audio"
        private const val EXTRA_BITRATE_KBPS = "bitrate_kbps"

        fun start(
            context: Context,
            resultCode: Int,
            projectionData: Intent,
            rtmpUrl: String,
            streamKey: String,
            width: Int,
            height: Int,
            fps: Int,
            videoKbps: Int,
            audioKbps: Int,
            micEnabled: Boolean,
            gameAudioEnabled: Boolean
        ) {
            val intent = Intent(context, StreamForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, projectionData)
                putExtra(EXTRA_URL, rtmpUrl)
                putExtra(EXTRA_KEY, streamKey)
                putExtra(EXTRA_WIDTH, width)
                putExtra(EXTRA_HEIGHT, height)
                putExtra(EXTRA_FPS, fps)
                putExtra(EXTRA_AUDIO_KBPS, audioKbps)
                putExtra(EXTRA_MIC, micEnabled)
                putExtra(EXTRA_GAME_AUDIO, gameAudioEnabled)
                putExtra(EXTRA_BITRATE_KBPS, videoKbps)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, StreamForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private var stream: GenericStream? = null
    private var projection: MediaProjection? = null

    private val connectChecker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {
            StreamStatus.set(Phase.CONNECTING, "Connecting...")
        }

        override fun onConnectionSuccess() {
            StreamStatus.set(Phase.LIVE, "You are LIVE")
        }

        override fun onConnectionFailed(reason: String) {
            Log.e(TAG, "Connection failed: $reason")
            stopEverything(Phase.ERROR, "Connection failed: $reason")
        }

        override fun onNewBitrate(bitrate: Long) {
            StreamStatus.setBitrate(bitrate / 1000)
        }

        override fun onDisconnect() {
            if (StreamStatus.state.value.phase != Phase.ERROR) {
                StreamStatus.set(Phase.IDLE, "Disconnected")
            }
        }

        override fun onAuthError() {
            stopEverything(Phase.ERROR, "Auth error: stream key ya URL galat hai")
        }

        override fun onAuthSuccess() {}
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> stopEverything(Phase.IDLE, "Stream stopped")
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        val wantMic = intent.getBooleanExtra(EXTRA_MIC, true)
        val micGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        val useMic = wantMic && micGranted

        // 1) Foreground pehle (Android 14+ requirement)
        try {
            startForegroundWithTypes(useMic)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            stopEverything(Phase.ERROR, "Service start nahi hui: ${e.message}")
            return
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopEverything(Phase.ERROR, "Screen capture permission nahi mili")
            return
        }

        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        val key = intent.getStringExtra(EXTRA_KEY).orEmpty().trim()
        val width = intent.getIntExtra(EXTRA_WIDTH, 1280)
        val height = intent.getIntExtra(EXTRA_HEIGHT, 720)
        val fps = intent.getIntExtra(EXTRA_FPS, 30)
        val audioKbps = intent.getIntExtra(EXTRA_AUDIO_KBPS, 128)
        val useGameAudio = intent.getBooleanExtra(EXTRA_GAME_AUDIO, true)
        val bitrateKbps = intent.getIntExtra(EXTRA_BITRATE_KBPS, 4000)

        StreamStatus.set(Phase.CONNECTING, "Preparing...")
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(resultCode, data)
            // Android 14+: capture shuru karne se pehle callback register karna zaroori hai
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopEverything(Phase.IDLE, "Screen sharing band ho gayi")
                }
            }, Handler(Looper.getMainLooper()))
            projection = mp

            val videoSource = ScreenSource(applicationContext, mp)

            val s = when {
                useMic && useGameAudio ->
                    GenericStream(this, connectChecker, videoSource, MixAudioSource(mp))
                useGameAudio ->
                    GenericStream(this, connectChecker, videoSource, InternalAudioSource(mp))
                else ->
                    GenericStream(this, connectChecker, videoSource, MicrophoneSource())
            }
            stream = s

            val prepared = s.prepareVideo(width, height, bitrateKbps * 1000, fps) &&
                    s.prepareAudio(44100, true, audioKbps * 1000)
            if (!prepared) {
                stopEverything(Phase.ERROR, "Is phone par video/audio encoder prepare nahi hua")
                return
            }

            val endpoint = url.trimEnd('/') + "/" + key
            s.startStream(endpoint)
        } catch (e: Exception) {
            Log.e(TAG, "Start failed", e)
            stopEverything(Phase.ERROR, "Start failed: ${e.message}")
        }
    }

    private fun startForegroundWithTypes(useMic: Boolean) {
        val notification = buildNotification("4 LIVE is broadcasting your screen", "Streaming...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (useMic) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIFICATION_ID, notification, types)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private fun stopEverything(phase: Phase, message: String) {
        mainHandler.post { stopOnMain(phase, message) }
    }

    private fun stopOnMain(phase: Phase, message: String) {
        try {
            stream?.let {
                if (it.isStreaming) it.stopStream()
                it.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "stop stream: ${e.message}")
        }
        stream = null
        try {
            projection?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "stop projection: ${e.message}")
        }
        projection = null
        StreamStatus.set(phase, message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(title: String, text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, StreamForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "End Stream", stopIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "4 LIVE Active Broadcast", NotificationManager.IMPORTANCE_LOW
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        try {
            stream?.let {
                if (it.isStreaming) it.stopStream()
                it.release()
            }
        } catch (_: Exception) {}
        stream = null
        projection = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
