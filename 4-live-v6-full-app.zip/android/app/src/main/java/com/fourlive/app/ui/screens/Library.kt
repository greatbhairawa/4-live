package com.fourlive.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fourlive.app.ui.AppState
import com.fourlive.app.ui.GAMES
import com.fourlive.app.ui.Screen
import com.fourlive.app.ui.components.Card1
import com.fourlive.app.ui.components.GameBanner
import com.fourlive.app.ui.components.GhostButton
import com.fourlive.app.ui.components.Muted
import com.fourlive.app.ui.components.Pill
import com.fourlive.app.ui.components.PrimaryButton
import com.fourlive.app.ui.components.SectionTitle
import com.fourlive.app.ui.components.StatBox
import com.fourlive.app.ui.components.SwitchRow
import com.fourlive.app.ui.components.TopBar
import com.fourlive.app.ui.theme.Pal

// 13. Game Library
@Composable
fun GameLibraryScreen(app: AppState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopBar("Game Library", onBack = null)
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Muted("Game chuno aur seedha stream shuru karo. Game screen capture se aati hai, koi extra setup nahi.", 13)
            GAMES.forEach { g ->
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    GameBanner(
                        g,
                        Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clickable { app.game = g; app.navigate(Screen.START_LIVE) }
                    )
                }
            }
        }
    }
}

// 14. Stream History
@Composable
fun StreamHistoryScreen(app: AppState) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Stream History", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (app.history.isEmpty()) Muted("Abhi koi stream nahi hui.", 13)
            app.history.forEach { h ->
                Card1 {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(h.title, modifier = Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                        if (h.score > 0) Pill("${h.score}", Pal.Emerald)
                    }
                    Muted("${h.game}  •  ${h.date}")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        StatBox("Duration", h.duration, Modifier.weight(1f))
                        StatBox("Views", "${h.views}", Modifier.weight(1f))
                        StatBox("Peak", "${h.peak}", Modifier.weight(1f))
                    }
                    Muted(h.platforms)
                }
            }
            Muted("\"Demo sample\" wali entries namune hain. Aapki asli streams yahin judti jayengi.", 11)
        }
    }
}

// 15. Profile
@Composable
fun ProfileScreen(app: AppState) {
    var editing by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf(app.userName) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopBar("Profile", onBack = null)
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Pal.Rose600, Pal.Amber))),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    app.userName.take(1).uppercase(),
                    fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color.White
                )
            }
            if (editing) {
                OutlinedTextField(
                    value = nameDraft, onValueChange = { nameDraft = it },
                    label = { Text("Streamer name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                PrimaryButton("Save", enabled = nameDraft.isNotBlank(), onClick = {
                    app.userName = nameDraft.trim()
                    app.saveProfile()
                    editing = false
                })
            } else {
                Text(app.userName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                if (app.email.isNotBlank()) Muted(app.email, 13)
                GhostButton("Edit profile", onClick = { nameDraft = app.userName; editing = true })
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatBox("Streams", "${app.history.size}", Modifier.weight(1f))
                StatBox("Followers", "-", Modifier.weight(1f))
                StatBox("Likes", "-", Modifier.weight(1f))
            }
            Muted("Followers aur likes Community system (Version 1.3) ke saath aayenge.", 11)

            GhostButton("Stream history", onClick = { app.navigate(Screen.STREAM_HISTORY) })
            GhostButton("Settings", onClick = { app.navigate(Screen.SETTINGS) })
        }
    }
}

// 16. Settings
@Composable
fun SettingsScreen(app: AppState) {
    var cleared by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Settings", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionTitle("Streaming")
            SwitchRow("Sirf WiFi par live", "Mobile data par stream roke", app.wifiOnly) { app.wifiOnly = it }
            GhostButton("Stream settings (resolution, FPS, bitrate)", onClick = { app.navigate(Screen.STREAM_SETTINGS) })
            GhostButton("Platforms aur stream keys", onClick = { app.navigate(Screen.PLATFORM_SELECT) })

            SectionTitle("Privacy")
            Muted("Stream keys is phone par encrypted save hoti hain.", 12)
            GhostButton(
                if (cleared) "Keys delete ho gayi" else "Saved stream keys delete karo",
                onClick = { app.clearKeys(); cleared = true }
            )

            SectionTitle("Account")
            GhostButton("Logout", onClick = { app.logout(); app.replace(Screen.AUTH) })

            SectionTitle("About")
            Muted("4 LIVE  •  Version 1.0 (foundation)", 13)
            Muted("Screen capture + mic + game audio live streaming.", 12)
        }
    }
}
