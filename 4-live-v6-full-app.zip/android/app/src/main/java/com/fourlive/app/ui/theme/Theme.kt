package com.fourlive.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg = Color(0xFF0A0A0A)
    val N900 = Color(0xFF171717)
    val N800 = Color(0xFF262626)
    val N700 = Color(0xFF404040)
    val N500 = Color(0xFF737373)
    val N400 = Color(0xFFA3A3A3)
    val N300 = Color(0xFFD4D4D4)
    val Text = Color(0xFFF5F5F5)
    val Rose = Color(0xFFF43F5E)
    val Rose600 = Color(0xFFE11D48)
    val Amber = Color(0xFFF59E0B)
    val Emerald = Color(0xFF34D399)
    val Cyan = Color(0xFF22D3EE)
    val Violet = Color(0xFF8B5CF6)
}

@Composable
fun FourLiveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Rose,
            onPrimary = Color.White,
            background = Pal.Bg,
            onBackground = Pal.Text,
            surface = Pal.N900,
            onSurface = Pal.Text,
            surfaceVariant = Pal.N800,
            onSurfaceVariant = Pal.N400,
            outline = Pal.N700,
            error = Pal.Rose
        ),
        content = content
    )
}
