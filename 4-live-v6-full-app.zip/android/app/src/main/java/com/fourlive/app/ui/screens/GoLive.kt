package com.fourlive.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fourlive.app.core.engine.Phase
import com.fourlive.app.core.engine.StreamStatus
import com.fourlive.app.ui.AppState
import com.fourlive.app.ui.GAMES
import com.fourlive.app.ui.Screen
import com.fourlive.app.ui.components.Card1
import com.fourlive.app.ui.components.Chip
import com.fourlive.app.ui.components.GameBanner
import com.fourlive.app.ui.components.GhostButton
import com.fourlive.app.ui.components.Muted
import com.fourlive.app.ui.components.Pill
import com.fourlive.app.ui.components.PrimaryButton
import com.fourlive.app.ui.components.SectionTitle
import com.fourlive.app.ui.components.StatBox
import com.fourlive.app.ui.components.StatusDot
import com.fourlive.app.ui.components.SwitchRow
import com.fourlive.app.ui.components.TopBar
import com.fourlive.app.ui.fmtDuration
import com.fourlive.app.ui.theme.Pal
import kotlinx.coroutines.delay

// 4. Start Live
@Composable
fun StartLiveScreen(app: AppState) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Start Live", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = app.title, onValueChange = { app.title = it },
                label = { Text("Stream title") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = app.description, onValueChange = { app.description = it },
                label = { Text("Description") }, minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            SectionTitle("Game")
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GAMES.forEach { g ->
                    val selected = app.game.id == g.id
                    Box(
                        modifier = Modifier
                            .width(140.dp)
                            .height(84.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (selected) Pal.Rose else Color.Transparent)
                            .padding(if (selected) 2.dp else 0.dp)
                    ) {
                        GameBanner(g, Modifier.fillMaxSize().clickable { app.game = g })
                    }
                }
            }

            SectionTitle("Privacy")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Public", "Unlisted", "Private").forEach { p ->
                    Chip(p, app.privacy == p) { app.privacy = p }
                }
            }

            OutlinedTextField(
                value = app.tags, onValueChange = { app.tags = it },
                label = { Text("Tags (comma se alag)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Column(modifier = Modifier.padding(16.dp)) {
            PrimaryButton("Next: Choose platforms", onClick = { app.navigate(Screen.PLATFORM_SELECT) })
        }
    }
}

// 5. Platform Selection
@Composable
fun PlatformSelectScreen(app: AppState) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Choose Platforms", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Muted("YouTube, Twitch, KICK aur Facebook ka URL aur stream key daalo.", 13)

            app.platforms.forEach { p ->
                Card1(borderColor = if (p.selected) p.color else Pal.N800) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatusDot(p.color, 12)
                        Text(p.name, modifier = Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                        if (p.selected && p.ready) Pill("Ready", Pal.Emerald)
                        if (p.selected && !p.ready) Pill("Key chahiye", Pal.Amber)
                        Switch(checked = p.selected, onCheckedChange = { p.selected = it })
                    }
                    if (p.selected) {
                        OutlinedTextField(
                            value = p.url, onValueChange = { p.url = it },
                            label = { Text("Server URL") }, singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = p.key, onValueChange = { p.key = it },
                            label = { Text("Stream key") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Muted(p.hint, 11)
                    }
                }
            }

            if (app.selectedPlatforms().size > 1) {
                Card1(borderColor = Pal.Amber) {
                    Text(
                        "Abhi app ek hi platform par live bhejta hai (pehla ready wala). Ek saath 4 platform Version 1.1 ke relay support mein aayega.",
                        fontSize = 12.sp, color = Pal.Amber
                    )
                }
            }
        }
        Column(modifier = Modifier.padding(16.dp)) {
            PrimaryButton(
                "Next: Stream settings",
                enabled = app.selectedPlatforms().isNotEmpty(),
                onClick = { app.savePlatforms(); app.navigate(Screen.STREAM_SETTINGS) }
            )
        }
    }
}

// 6. Stream Settings
@Composable
fun StreamSettingsScreen(app: AppState, fromWizard: Boolean) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Stream Settings", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionTitle("Resolution")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(480, 720, 1080).forEach { r -> Chip("${r}p", app.resolution == r) { app.resolution = r } }
            }
            SectionTitle("Frame rate")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60).forEach { f -> Chip("$f FPS", app.fps == f) { app.fps = f } }
            }
            SectionTitle("Orientation")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Landscape", app.landscape) { app.landscape = true }
                Chip("Portrait", !app.landscape) { app.landscape = false }
            }

            SectionTitle("Bitrate")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Auto", app.autoBitrate) { app.autoBitrate = true }
                Chip("Manual", !app.autoBitrate) { app.autoBitrate = false }
            }
            if (app.autoBitrate) {
                Muted("Auto: ${app.videoBitrateKbps()} kbps (resolution aur FPS ke hisaab se)", 13)
            } else {
                Text("${app.manualBitrateKbps} kbps", color = Pal.Text, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = app.manualBitrateKbps.toFloat(),
                    onValueChange = { app.manualBitrateKbps = (it / 100f).toInt() * 100 },
                    valueRange = 500f..8000f
                )
                Muted("Mobile data par 2000-2500 kbps rakho. 3000 kbps lagbhag 1.35 GB per ghanta leta hai.", 11)
            }

            SectionTitle("Audio")
            SwitchRow("Microphone", "Aapki awaaz", app.mic) { app.mic = it }
            SwitchRow("Game / internal audio", "Game ki awaaz (Android 10+)", app.gameAudio) { app.gameAudio = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(128, 160, 192).forEach { b -> Chip("$b kbps", app.audioBitrateKbps == b) { app.audioBitrateKbps = b } }
            }

            SwitchRow("Camera (facecam)", "Version 1.2 mein aayega", app.camera, enabled = false) { app.camera = it }
            SwitchRow("Sirf WiFi par live", "Mobile data se galti se live na ho", app.wifiOnly) { app.wifiOnly = it }
        }
        Column(modifier = Modifier.padding(16.dp)) {
            PrimaryButton(
                if (fromWizard) "Next: Preview" else "Done",
                onClick = { if (fromWizard) app.navigate(Screen.LIVE_PREVIEW) else app.back() }
            )
        }
    }
}

// 7. Live Preview
@Composable
fun LivePreviewScreen(app: AppState, onGoLive: () -> Unit) {
    val dest = app.primaryDestination()
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Live Preview", onBack = { app.back() })
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(app.game.colorA, app.game.colorB))),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(app.game.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Go Live dabane par aapki poori screen stream hogi", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                }
            }

            Card1 {
                Text(app.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                Muted("${app.game.name}  •  ${app.privacy}")
            }

            Card1 {
                SectionTitle("Summary")
                SummaryRow("Video", "${app.resolution}p ${app.fps}fps, ${if (app.landscape) "landscape" else "portrait"}")
                SummaryRow("Bitrate", "${app.videoBitrateKbps()} kbps")
                SummaryRow("Mic", if (app.mic) "On" else "Off")
                SummaryRow("Game audio", if (app.gameAudio) "On" else "Off")
                SummaryRow("Destination", dest?.name ?: "Koi ready platform nahi")
            }

            if (dest == null) {
                Card1(borderColor = Pal.Amber) {
                    Text("Platform select karke URL aur stream key daalo, tabhi Go Live chalega.", fontSize = 12.sp, color = Pal.Amber)
                }
            }
        }
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PrimaryButton("GO LIVE", enabled = dest != null, onClick = onGoLive)
            GhostButton("Edit platforms", onClick = { app.navigate(Screen.PLATFORM_SELECT) })
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Muted(label, 13)
        Text(value, fontSize = 13.sp, color = Pal.Text, fontWeight = FontWeight.Medium)
    }
}

// 8. Live Streaming (asli engine ka status)
@Composable
fun LiveStreamingScreen(app: AppState, onStop: () -> Unit) {
    val state by StreamStatus.state.collectAsState()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(state.phase) {
        if (state.phase == Phase.LIVE && app.liveStartMs == 0L) {
            app.liveStartMs = System.currentTimeMillis()
        }
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val seconds = if (state.phase == Phase.LIVE && app.liveStartMs > 0L) (now - app.liveStartMs) / 1000 else 0L
    val statusText = when (state.phase) {
        Phase.LIVE -> "LIVE"
        Phase.CONNECTING -> "CONNECTING"
        Phase.ERROR -> "ERROR"
        Phase.IDLE -> "ENDED"
    }
    val statusColor = when (state.phase) {
        Phase.LIVE -> Pal.Rose
        Phase.CONNECTING -> Pal.Amber
        Phase.ERROR -> Pal.Rose
        Phase.IDLE -> Pal.N400
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Live Streaming", onBack = null)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card1(borderColor = statusColor) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatusDot(statusColor, 12)
                    Text(statusText, fontSize = 20.sp, fontWeight = FontWeight.Black, color = statusColor)
                    Spacer(Modifier.weight(1f))
                    Text(fmtDuration(seconds), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                }
                if (state.message.isNotBlank()) Text(state.message, fontSize = 13.sp, color = Pal.N300)
                Muted(app.title, 12)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatBox("Bitrate", "${state.bitrateKbps} kbps", Modifier.weight(1f))
                StatBox("Video", "${app.resolution}p ${app.fps}", Modifier.weight(1f))
                StatBox("Audio", if (app.mic && app.gameAudio) "Mic + Game" else if (app.mic) "Mic" else "Game", Modifier.weight(1f))
            }

            Card1 {
                SectionTitle("Viewers")
                Muted("Viewer count aur follow alerts platform API se aayenge (Version 1.3). Abhi apne platform ka dashboard dekho.", 12)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                GhostButton("Chat", onClick = { app.navigate(Screen.CHAT) }, modifier = Modifier.weight(1f))
                GhostButton("Overlays", onClick = { app.navigate(Screen.OVERLAYS) }, modifier = Modifier.weight(1f))
            }
        }
        Column(modifier = Modifier.padding(16.dp)) {
            val finished = state.phase == Phase.IDLE || state.phase == Phase.ERROR
            PrimaryButton(
                if (finished) "Back to Home" else "END STREAM",
                color = if (finished) Pal.N700 else Pal.Rose600,
                onClick = onStop
            )
        }
    }
}
