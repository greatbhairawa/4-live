package com.fourlive.app.core.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class Phase { IDLE, CONNECTING, LIVE, ERROR }

data class StreamUiState(
    val phase: Phase = Phase.IDLE,
    val message: String = "",
    val bitrateKbps: Long = 0L
)

/** Service aur UI ke beech ka shared status. */
object StreamStatus {
    private val _state = MutableStateFlow(StreamUiState())
    val state: StateFlow<StreamUiState> = _state.asStateFlow()

    fun set(phase: Phase, message: String = "") {
        _state.value = StreamUiState(phase, message, if (phase == Phase.LIVE) _state.value.bitrateKbps else 0L)
    }

    fun setBitrate(kbps: Long) {
        _state.value = _state.value.copy(bitrateKbps = kbps)
    }
}
