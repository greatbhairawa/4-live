package com.fourlive.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.fourlive.app.ui.AppState
import com.fourlive.app.ui.GAMES
import com.fourlive.app.ui.Screen
import com.fourlive.app.ui.components.Card1
import com.fourlive.app.ui.components.GameBanner
import com.fourlive.app.ui.components.LogoMark
import com.fourlive.app.ui.components.Muted
import com.fourlive.app.ui.components.Pill
import com.fourlive.app.ui.components.PrimaryButton
import com.fourlive.app.ui.components.SectionTitle
import com.fourlive.app.ui.components.StatusDot
import com.fourlive.app.ui.theme.Pal
import kotlinx.coroutines.delay

// 1. Splash
@Composable
fun SplashScreen(app: AppState) {
    LaunchedEffect(Unit) {
        delay(1400)
        app.replace(if (app.loggedIn) Screen.HOME else Screen.AUTH)
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Pal.Bg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            LogoMark(size = 96)
            Text("4 LIVE", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Pal.Text)
            Muted("Stream your game. Everywhere.", 14)
        }
    }
}

// 2. Login / Signup (abhi sirf is phone par local profile)
@Composable
fun AuthScreen(app: AppState) {
    var signup by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(app.userName.takeIf { it != "Streamer" } ?: "") }
    var email by remember { mutableStateOf(app.email) }
    var pass by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Pal.Bg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        LogoMark(size = 64)
        Text(if (signup) "Create account" else "Welcome back", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
        Muted("Creator profile banao aur live jao", 13)

        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Streamer name") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = pass, onValueChange = { pass = it },
            label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        PrimaryButton(
            text = if (signup) "Sign up" else "Continue",
            enabled = name.isNotBlank(),
            onClick = {
                app.userName = name.trim()
                app.email = email.trim()
                app.loggedIn = true
                app.saveProfile()
                app.replace(Screen.HOME)
            }
        )
        Text(
            if (signup) "Already have an account? Login" else "New here? Create account",
            color = Pal.Rose, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.clickable { signup = !signup }
        )
        Text(
            "Skip for now",
            color = Pal.N400, fontSize = 13.sp,
            modifier = Modifier.clickable { app.replace(Screen.HOME) }
        )
        Muted("Abhi profile sirf is phone par save hota hai. Cloud login Version 1.3 mein aayega.", 11)
    }
}

// 3. Home
@Composable
fun HomeScreen(app: AppState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LogoMark(size = 34)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("4 LIVE", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Text)
                    StatusDot(Pal.Emerald)
                }
                Muted("Hi ${app.userName}, ready to broadcast", 11)
            }
            IconButton(onClick = { app.navigate(Screen.STREAM_SETTINGS) }) {
                Icon(Icons.Filled.Tune, contentDescription = "Stream settings", tint = Pal.Cyan)
            }
            IconButton(onClick = { app.navigate(Screen.SETTINGS) }) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Pal.N300)
            }
        }

        // Hero: GO LIVE
        Box(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF2A0E16), Pal.N900)))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Pill("Mobile screen cast engine", Pal.Rose)
                Text("Start Streaming", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Text)
                Text(
                    "Screen + mic + game audio ek saath, YouTube, Twitch, KICK aur Facebook ke liye.",
                    fontSize = 13.sp, color = Pal.N400, textAlign = TextAlign.Center
                )
                PrimaryButton(text = "GO LIVE", onClick = { app.navigate(Screen.START_LIVE) })
            }
        }

        // Quick tools
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("Quick Tools")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickTool("Settings", Icons.Filled.Tune, Pal.Cyan, Modifier.weight(1f)) { app.navigate(Screen.STREAM_SETTINGS) }
                QuickTool("Scenes", Icons.Filled.Layers, Pal.Violet, Modifier.weight(1f)) { app.goTab(Screen.SCENES) }
                QuickTool("Overlays", Icons.Filled.Image, Pal.Amber, Modifier.weight(1f)) { app.navigate(Screen.OVERLAYS) }
                QuickTool("Chat", Icons.Filled.Chat, Pal.Emerald, Modifier.weight(1f)) { app.navigate(Screen.CHAT) }
            }
        }

        // Gaming section
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) { SectionTitle("Gaming Section") }
                Text("See all", color = Pal.Rose, fontSize = 13.sp, modifier = Modifier.clickable { app.goTab(Screen.GAME_LIBRARY) })
            }
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GAMES.forEach { g ->
                    GameBanner(
                        g,
                        Modifier
                            .width(150.dp)
                            .height(96.dp)
                            .clickable { app.game = g; app.navigate(Screen.START_LIVE) }
                    )
                }
            }
        }

        // Recent streams
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.weight(1f)) { SectionTitle("Recent Streams") }
                Text("History", color = Pal.Rose, fontSize = 13.sp, modifier = Modifier.clickable { app.navigate(Screen.STREAM_HISTORY) })
            }
            app.history.take(3).forEach { h ->
                Card1 {
                    Text(h.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Pal.Text)
                    Muted("${h.game}  •  ${h.duration}  •  ${h.platforms}")
                }
            }
        }

        // Notifications
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Notifications, contentDescription = null, tint = Pal.Amber, modifier = Modifier.size(18.dp))
                SectionTitle("Notifications")
            }
            Card1 {
                Text("Tip: earphone lagao taaki mic game ki awaaz na utha le.", fontSize = 13.sp, color = Pal.N300)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun QuickTool(label: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Pal.N900)
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = color)
        Text(label, fontSize = 11.sp, color = Pal.N300)
    }
}
